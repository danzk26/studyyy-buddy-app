package com.studybuddy.app.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Pure-Java helpers that turn the raw bytes of an uploaded file into clean, readable text.
 * The real file type is detected from the file's first bytes (not its name), and each format is
 * decoded the right way. Anything that cannot be read as real text is rejected with a clear message.
 */
public final class DocumentParsers {

    /** Maximum characters kept from a document (keeps the generator fast on big files). */
    public static final int MAX_CHARS = 60000;

    private static final int MAX_ENTRY_BYTES = 30 * 1024 * 1024;

    /** Thrown when a file is valid but cannot be turned into readable text. */
    public static class UnsupportedDocumentException extends IOException {
        public UnsupportedDocumentException(String message) {
            super(message);
        }
    }

    public enum Type { PDF, DOCX, PPTX, LEGACY_OFFICE, OTHER_ZIP, TEXT }

    private DocumentParsers() {}

    public static Type detect(byte[] d) {
        if (d.length >= 4 && d[0] == '%' && d[1] == 'P' && d[2] == 'D' && d[3] == 'F') {
            return Type.PDF;
        }
        if (d.length >= 8 && (d[0] & 0xFF) == 0xD0 && (d[1] & 0xFF) == 0xCF
                && (d[2] & 0xFF) == 0x11 && (d[3] & 0xFF) == 0xE0) {
            return Type.LEGACY_OFFICE;
        }
        if (d.length >= 4 && d[0] == 'P' && d[1] == 'K' && d[2] == 3 && d[3] == 4) {
            try {
                boolean docx = false;
                boolean pptx = false;
                ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(d));
                ZipEntry e;
                while ((e = zis.getNextEntry()) != null) {
                    String n = e.getName();
                    if (n.equals("word/document.xml")) docx = true;
                    if (n.startsWith("ppt/slides/slide")) pptx = true;
                    zis.closeEntry();
                }
                zis.close();
                if (docx) return Type.DOCX;
                if (pptx) return Type.PPTX;
            } catch (IOException ignored) {
                // fall through to OTHER_ZIP
            }
            return Type.OTHER_ZIP;
        }
        return Type.TEXT;
    }

    /** Reads every non-PDF file type. */
    public static String extractText(byte[] data) throws IOException {
        Type type = detect(data);
        switch (type) {
            case DOCX:
                return cleanText(extractDocx(data));
            case PPTX:
                return cleanText(extractPptx(data));
            case LEGACY_OFFICE:
                throw new UnsupportedDocumentException(
                        "Old Office files (.doc, .ppt, .xls) are not supported. "
                                + "Please save the file as .docx, .pptx or PDF and try again.");
            case OTHER_ZIP:
                throw new UnsupportedDocumentException(
                        "This archive type is not supported. Upload a PDF, .docx, .pptx or text file.");
            case PDF:
                throw new UnsupportedDocumentException("PDF files must be read with the PDF reader.");
            default:
                String text = decodeText(data);
                if (looksBinary(text)) {
                    throw new UnsupportedDocumentException(
                            "This file is not readable text (it looks like a picture or binary file). "
                                    + "Upload a PDF, .docx, .pptx, .txt or .md file.");
                }
                return cleanText(text);
        }
    }

    private static String decodeText(byte[] d) {
        if (d.length >= 2 && (d[0] & 0xFF) == 0xFF && (d[1] & 0xFF) == 0xFE) {
            return new String(d, 2, d.length - 2, StandardCharsets.UTF_16LE);
        }
        if (d.length >= 2 && (d[0] & 0xFF) == 0xFE && (d[1] & 0xFF) == 0xFF) {
            return new String(d, 2, d.length - 2, StandardCharsets.UTF_16BE);
        }
        if (d.length >= 3 && (d[0] & 0xFF) == 0xEF && (d[1] & 0xFF) == 0xBB && (d[2] & 0xFF) == 0xBF) {
            return new String(d, 3, d.length - 3, StandardCharsets.UTF_8);
        }
        return new String(d, StandardCharsets.UTF_8);
    }

    /** True when the text is mostly control / replacement characters (i.e. garbage). */
    public static boolean looksBinary(String s) {
        if (s == null || s.isEmpty()) return false;
        int n = Math.min(s.length(), 4000);
        int bad = 0;
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == 0 || c == '\uFFFD'
                    || (c < 32 && c != '\n' && c != '\r' && c != '\t' && c != '\f')) {
                bad++;
            }
        }
        return bad * 100 >= n * 3;
    }

    public static String cleanText(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\r\n", "\n").replace('\r', '\n');
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\t') {
                sb.append(c);
            } else if (c == '\u00A0') {
                sb.append(' ');
            } else if (Character.isISOControl(c) || c == '\uFFFD' || c == '\u200B' || c == '\uFEFF') {
                // drop control / invisible / replacement characters
            } else {
                sb.append(c);
            }
        }
        s = sb.toString()
                .replaceAll("[ \\t]+", " ")
                .replaceAll(" ?\n ?", "\n")
                .replaceAll("\n{3,}", "\n\n")
                .trim();
        if (s.length() > MAX_CHARS) {
            int cut = s.lastIndexOf('\n', MAX_CHARS);
            if (cut < MAX_CHARS / 2) cut = s.lastIndexOf(' ', MAX_CHARS);
            if (cut < MAX_CHARS / 2) cut = MAX_CHARS;
            s = s.substring(0, cut).trim();
        }
        return s;
    }

    private static String extractDocx(byte[] data) throws IOException {
        Map<String, String> parts = readZipText(data, "word/document.xml", null);
        String xml = parts.get("word/document.xml");
        if (xml == null) {
            throw new UnsupportedDocumentException("This Word file has no readable text.");
        }
        xml = xml.replace("</w:p>", "\n")
                .replaceAll("<w:br[^>]*/>", "\n")
                .replaceAll("<w:tab[^>]*/>", "\t")
                .replace("</w:tc>", "\t");
        xml = xml.replaceAll("<[^>]+>", "");
        return decodeEntities(xml);
    }

    private static final Pattern SLIDE_NAME = Pattern.compile("ppt/slides/slide(\\d+)\\.xml");
    private static final Pattern A_TEXT = Pattern.compile("<a:t(?:\\s[^>]*)?>(.*?)</a:t>", Pattern.DOTALL);

    private static String extractPptx(byte[] data) throws IOException {
        Map<String, String> parts = readZipText(data, null, "ppt/slides/slide");
        TreeMap<Integer, String> slides = new TreeMap<>();
        for (Map.Entry<String, String> e : parts.entrySet()) {
            Matcher m = SLIDE_NAME.matcher(e.getKey());
            if (m.matches()) {
                try {
                    slides.put(Integer.parseInt(m.group(1)), e.getValue());
                } catch (NumberFormatException ignored) {
                    // skip odd names
                }
            }
        }
        if (slides.isEmpty()) {
            throw new UnsupportedDocumentException("This PowerPoint file has no readable text.");
        }
        StringBuilder out = new StringBuilder();
        for (Map.Entry<Integer, String> slide : slides.entrySet()) {
            StringBuilder body = new StringBuilder();
            for (String para : slide.getValue().split("</a:p>")) {
                Matcher m = A_TEXT.matcher(para);
                StringBuilder line = new StringBuilder();
                while (m.find()) line.append(decodeEntities(m.group(1)));
                if (line.length() > 0) body.append(line).append('\n');
            }
            if (body.length() > 0) {
                out.append("Slide ").append(slide.getKey()).append('\n').append(body).append('\n');
            }
        }
        return out.toString();
    }

    private static Map<String, String> readZipText(byte[] data, String exact, String prefix)
            throws IOException {
        Map<String, String> result = new TreeMap<>();
        ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));
        try {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                String name = e.getName();
                boolean wanted = (exact != null && name.equals(exact))
                        || (prefix != null && name.startsWith(prefix) && name.endsWith(".xml"));
                if (wanted) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    long total = 0;
                    while ((n = zis.read(buf)) != -1) {
                        total += n;
                        if (total > MAX_ENTRY_BYTES) {
                            throw new UnsupportedDocumentException("This document is too large to read.");
                        }
                        bos.write(buf, 0, n);
                    }
                    result.put(name, new String(bos.toByteArray(), StandardCharsets.UTF_8));
                }
                zis.closeEntry();
            }
        } finally {
            zis.close();
        }
        return result;
    }

    private static final Pattern NUM_ENTITY = Pattern.compile("&#(x?)([0-9a-fA-F]+);");

    static String decodeEntities(String s) {
        s = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'");
        Matcher m = NUM_ENTITY.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            int cp;
            try {
                cp = Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16);
            } catch (NumberFormatException ex) {
                cp = 32;
            }
            if (!Character.isValidCodePoint(cp)) cp = 32;
            m.appendReplacement(sb, Matcher.quoteReplacement(new String(Character.toChars(cp))));
        }
        m.appendTail(sb);
        return sb.toString().replace("&amp;", "&");
    }
}
