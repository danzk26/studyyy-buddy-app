package com.studybuddy.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.studybuddy.app.MainActivity;
import com.studybuddy.app.R;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Auth;

/** Log in with a username and password. */
public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private TextView tvError;
    private MaterialButton btnLogin;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        tvError = findViewById(R.id.tv_error);
        btnLogin = findViewById(R.id.btn_login);
        progress = findViewById(R.id.progress);

        btnLogin.setOnClickListener(v -> attemptLogin());
        etPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptLogin();
                return true;
            }
            return false;
        });
        findViewById(R.id.tv_to_signup).setOnClickListener(v ->
                startActivity(new Intent(this, SignUpActivity.class)));
    }

    private void attemptLogin() {
        final String username = etUsername.getText() == null ? "" : etUsername.getText().toString();
        final String password = etPassword.getText() == null ? "" : etPassword.getText().toString();
        tvError.setVisibility(View.GONE);
        setBusy(true);
        Async.<Auth.Result>load(() -> Auth.login(getApplicationContext(), username, password), res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            setBusy(false);
            if (res == null) {
                showError("Something went wrong. Please try again.");
            } else if (!res.ok()) {
                showError(res.error);
            } else {
                openApp();
            }
        });
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private void showError(String message) {
        tvError.setText(message);
        tvError.setVisibility(View.VISIBLE);
    }

    private void setBusy(boolean busy) {
        btnLogin.setEnabled(!busy);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }
}
