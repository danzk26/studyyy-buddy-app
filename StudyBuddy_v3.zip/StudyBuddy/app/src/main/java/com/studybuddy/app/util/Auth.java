package com.studybuddy.app.util;

import android.content.Context;
import android.database.sqlite.SQLiteConstraintException;

import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.data.User;

import java.util.regex.Pattern;

/**
 * Sign-up and log-in. Accounts live in the on-device database (Room).
 * Call these from a background thread (hashing a password takes a moment on purpose).
 */
public final class Auth {
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9_]{3,20}$");

    private Auth() {
    }

    public static final class Result {
        public final User user;
        public final String error;

        private Result(User user, String error) {
            this.user = user;
            this.error = error;
        }

        public boolean ok() {
            return user != null;
        }
    }

    private static Result fail(String message) {
        return new Result(null, message);
    }

    public static Result register(Context context, String displayName, String username,
                                  String password, String confirm) {
        String name = displayName == null ? "" : displayName.trim();
        String uname = username == null ? "" : username.trim();
        if (name.isEmpty() || name.length() > 30) {
            return fail("Enter your name (up to 30 characters).");
        }
        if (!USERNAME.matcher(uname).matches()) {
            return fail("Username must be 3-20 letters, numbers or underscores.");
        }
        if (password == null || password.length() < 6) {
            return fail("Password must be at least 6 characters.");
        }
        if (!password.equals(confirm)) {
            return fail("The two passwords do not match.");
        }
        StudyDao dao = AppDatabase.get(context).dao();
        if (dao.userByName(uname) != null) {
            return fail("That username is already taken.");
        }
        String salt = PasswordHasher.newSalt();
        User user = new User(uname, name, salt, PasswordHasher.hash(password, salt));
        try {
            user.id = dao.insertUser(user);
        } catch (SQLiteConstraintException e) {
            return fail("That username is already taken.");
        }
        Session.login(context, user);
        return new Result(user, null);
    }

    public static Result login(Context context, String username, String password) {
        String uname = username == null ? "" : username.trim();
        if (uname.isEmpty() || password == null || password.isEmpty()) {
            return fail("Enter your username and password.");
        }
        User user = AppDatabase.get(context).dao().userByName(uname);
        if (user == null || !PasswordHasher.matches(password, user.salt, user.passwordHash)) {
            return fail("Wrong username or password.");
        }
        Session.login(context, user);
        return new Result(user, null);
    }
}
