package com.studybuddy.app.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.studybuddy.app.R;
import com.studybuddy.app.ai.AiResult;
import com.studybuddy.app.ai.TeacherActions;
import com.studybuddy.app.ai.TeacherAI;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.ChatMessage;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.AppSettings;
import com.studybuddy.app.util.Markdown;
import com.studybuddy.app.util.Session;
import com.studybuddy.app.util.Voice;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * The online AI Teacher: chat with memory, speaks its answers out loud, listens to your voice,
 * explains any topic, and can create new reviewers (topics) and start quizzes on request.
 */
public class TeacherFragment extends Fragment {

    private final List<ChatMessage> messages = new ArrayList<>();
    private ChatMessage typing;
    private boolean busy = false;

    private RecyclerView rv;
    private ChatAdapter adapter;
    private EditText etMessage;
    private TextView btnVoice;
    private Voice voice;

    /** Result of the system speech-recognition screen (the microphone button). */
    private final ActivityResultLauncher<Intent> speechLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getData() == null) {
                    return;
                }
                ArrayList<String> heard = result.getData()
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (heard != null && !heard.isEmpty() && heard.get(0) != null && !heard.get(0).trim().isEmpty()) {
                    send(heard.get(0).trim());
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_teacher, container, false);
        rv = v.findViewById(R.id.rv_chat);
        etMessage = v.findViewById(R.id.et_message);
        btnVoice = v.findViewById(R.id.btn_voice);

        LinearLayoutManager lm = new LinearLayoutManager(requireContext());
        lm.setStackFromEnd(true);
        rv.setLayoutManager(lm);
        adapter = new ChatAdapter();
        rv.setAdapter(adapter);

        voice = new Voice(requireContext());
        updateVoiceButton();
        btnVoice.setOnClickListener(x -> {
            boolean on = !AppSettings.voiceOn(requireContext());
            AppSettings.setVoiceOn(requireContext(), on);
            if (!on) {
                voice.stop();
            }
            updateVoiceButton();
            Toast.makeText(requireContext(), on ? "🔊 Teacher voice on" : "🔇 Teacher voice off", Toast.LENGTH_SHORT).show();
        });
        v.findViewById(R.id.btn_settings).setOnClickListener(x ->
                startActivity(new Intent(requireContext(), SettingsActivity.class)));
        v.findViewById(R.id.btn_clear).setOnClickListener(x -> clearChat());
        v.findViewById(R.id.btn_send).setOnClickListener(x -> sendFromBox());
        v.findViewById(R.id.btn_mic).setOnClickListener(x -> listen());
        etMessage.setOnEditorActionListener((tv, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendFromBox();
                return true;
            }
            return false;
        });

        v.findViewById(R.id.chip_quiz).setOnClickListener(x -> send("Quiz me on my notes!"));
        v.findViewById(R.id.chip_study).setOnClickListener(x -> send("What should I study next?"));
        v.findViewById(R.id.chip_teach).setOnClickListener(x ->
                send("Teach me something interesting and surprising, then check my understanding."));
        v.findViewById(R.id.chip_create).setOnClickListener(x -> {
            etMessage.setText("Create a reviewer about ");
            etMessage.setSelection(etMessage.getText().length());
            etMessage.requestFocus();
        });
        v.findViewById(R.id.chip_explain).setOnClickListener(x -> {
            etMessage.setText("Explain like I'm 10: ");
            etMessage.setSelection(etMessage.getText().length());
            etMessage.requestFocus();
        });

        loadHistory();
        return v;
    }

    private void updateVoiceButton() {
        btnVoice.setText(AppSettings.voiceOn(requireContext()) ? "🔊" : "🔇");
    }

    private String welcome() {
        return "Hi " + Session.displayName(requireContext()) + "! I'm your AI Teacher 🤖\n\n"
                + "I can **teach any topic** (and read it out loud), **quiz you**, and **create new reviewers** "
                + "whenever you ask.\n\nTry:\n- \"Teach me about volcanoes\"\n- \"Create a reviewer about the Philippine Revolution\"\n"
                + "- Tap the 🎤 and just talk to me!";
    }

    private void loadHistory() {
        final Context appContext = requireContext().getApplicationContext();
        final long uid = Session.userId(appContext);
        final String welcomeText = welcome();
        Async.<List<ChatMessage>>load(() -> {
            StudyDao dao = AppDatabase.get(appContext).dao();
            List<ChatMessage> history = dao.chat(uid, 60);
            if (history.isEmpty()) {
                ChatMessage w = new ChatMessage(false, welcomeText);
                w.userId = uid;
                dao.insertChat(w);
                history.add(w);
            }
            return history;
        }, history -> {
            if (!isAdded() || history == null) {
                return;
            }
            messages.clear();
            messages.addAll(history);
            adapter.notifyDataSetChanged();
            scrollToEnd();
        });
    }

    private void clearChat() {
        final Context appContext = requireContext().getApplicationContext();
        final long uid = Session.userId(appContext);
        voice.stop();
        messages.clear();
        typing = null;
        busy = false;
        final ChatMessage w = new ChatMessage(false, welcome());
        w.userId = uid;
        messages.add(w);
        adapter.notifyDataSetChanged();
        Async.io(() -> {
            StudyDao dao = AppDatabase.get(appContext).dao();
            dao.clearChat(uid);
            dao.insertChat(w);
        });
    }

    private void listen() {
        if (busy) {
            return;
        }
        voice.stop();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask your teacher…");
        try {
            speechLauncher.launch(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(requireContext(), "Speech input isn't available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    private void sendFromBox() {
        String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) {
            return;
        }
        etMessage.setText("");
        send(text);
    }

    private void scrollToEnd() {
        if (adapter.getItemCount() > 0) {
            rv.scrollToPosition(adapter.getItemCount() - 1);
        }
    }

    // ------------------------------------------------------------------
    // Sending a message to the online AI
    // ------------------------------------------------------------------
    private void send(final String text) {
        if (busy || !isAdded()) {
            return;
        }
        final Context appContext = requireContext().getApplicationContext();
        final long uid = Session.userId(appContext);
        final String userName = Session.displayName(appContext);
        voice.stop();

        final List<ChatMessage> historyForAi = new ArrayList<>(messages);
        final ChatMessage userMsg = new ChatMessage(true, text);
        userMsg.userId = uid;
        messages.add(userMsg);
        typing = new ChatMessage(false, "💭 Thinking…");
        messages.add(typing);
        adapter.notifyDataSetChanged();
        scrollToEnd();
        busy = true;
        Async.io(() -> AppDatabase.get(appContext).dao().insertChat(userMsg));

        Async.<AiResult<TeacherAI.Result>>net(
                () -> TeacherAI.chat(appContext, userName, uid, historyForAi, text), res -> {
            if (!isAdded()) {
                busy = false;
                return;
            }
            if (res == null) {
                finishReply("⚠️ Something went wrong. Please try again.", false);
                return;
            }
            if (!res.ok()) {
                if (TeacherAI.NO_KEY.equals(res.error)) {
                    finishReply("🔑 I need an AI key before I can think!\n\nOpen **Settings** (⚙️ above), paste your free "
                            + "Gemini API key, and then ask me again.", false);
                    Snackbar.make(rv, "Add your AI key to wake up the teacher", Snackbar.LENGTH_LONG)
                            .setAction("Settings", x -> startActivity(new Intent(requireContext(), SettingsActivity.class)))
                            .show();
                } else {
                    finishReply("⚠️ " + res.error, false);
                }
                return;
            }
            handleResult(res.value, appContext, uid);
        });
    }

    private void handleResult(final TeacherAI.Result r, final Context appContext, final long uid) {
        if ("create_reviewer".equals(r.action) && r.args != null) {
            final JSONObject a = r.args;
            Async.<TeacherActions.Created>net(() -> TeacherActions.createReviewer(appContext, uid,
                    a.optString("subject", "General"), a.optString("title", "AI Topic"),
                    a.optString("content", "")), created -> {
                if (!isAdded()) {
                    busy = false;
                    return;
                }
                String intro = r.text.isEmpty() ? "Done! I wrote you a new reviewer." : r.text;
                if (created == null) {
                    finishReply(intro + "\n\n⚠️ I couldn't save the reviewer. Please try again.", true);
                } else {
                    finishReply(intro + "\n\n📚 **" + created.title + "** is now in your Library (" + created.subject
                            + ") with " + created.questions + " "
                            + (created.onlineQuestions ? "AI-written" : "practice") + " questions. "
                            + "Want me to quiz you on it?", true);
                }
            });
        } else if ("start_quiz".equals(r.action)) {
            final JSONObject a = r.args == null ? new JSONObject() : r.args;
            final int count = Math.max(3, Math.min(15, a.optInt("count", 8)));
            final String subject = a.optString("subject", "");
            Async.<Long>load(() -> TeacherActions.findSubjectId(appContext, uid, subject), sid -> {
                if (!isAdded()) {
                    busy = false;
                    return;
                }
                finishReply(r.text.isEmpty() ? "Let's go! Here's a quiz 🎮" : r.text, true);
                startActivity(QuizActivity.intent(requireContext(), "classic", sid == null ? 0 : sid, 0, count));
            });
        } else {
            finishReply(r.text, true);
        }
    }

    /** Shows the teacher's answer, saves it and (optionally) speaks it. */
    private void finishReply(String text, boolean speakIt) {
        busy = false;
        if (typing != null) {
            messages.remove(typing);
            typing = null;
        }
        final Context appContext = requireContext().getApplicationContext();
        final ChatMessage reply = new ChatMessage(false, text);
        reply.userId = Session.userId(appContext);
        messages.add(reply);
        adapter.notifyDataSetChanged();
        scrollToEnd();
        if (speakIt) {
            Async.io(() -> AppDatabase.get(appContext).dao().insertChat(reply));
            if (AppSettings.voiceOn(appContext)) {
                voice.speak(text);
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (voice != null) {
            voice.stop();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (voice != null) {
            voice.shutdown();
            voice = null;
        }
    }

    // ------------------------------------------------------------------
    // Chat list
    // ------------------------------------------------------------------
    private final class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.Holder> {

        final class Holder extends RecyclerView.ViewHolder {
            final LinearLayout box;
            final TextView tvMsg;
            final TextView tvListen;

            Holder(@NonNull View itemView) {
                super(itemView);
                box = itemView.findViewById(R.id.box);
                tvMsg = itemView.findViewById(R.id.tv_msg);
                tvListen = itemView.findViewById(R.id.tv_listen);
            }
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            final ChatMessage m = messages.get(position);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) h.box.getLayoutParams();
            if (m.fromUser) {
                lp.gravity = Gravity.END;
                h.box.setBackgroundResource(R.drawable.bubble_user);
                h.tvMsg.setTextColor(requireContext().getColor(R.color.white));
                h.tvMsg.setText(m.text);
                h.tvListen.setVisibility(View.GONE);
            } else {
                lp.gravity = Gravity.START;
                h.box.setBackgroundResource(R.drawable.bubble_ai);
                h.tvMsg.setTextColor(requireContext().getColor(R.color.text));
                h.tvMsg.setText(Markdown.render(m.text));
                boolean real = m != typing;
                h.tvListen.setVisibility(real ? View.VISIBLE : View.GONE);
                h.tvListen.setOnClickListener(x -> {
                    if (voice == null) {
                        return;
                    }
                    if (voice.isSpeaking()) {
                        voice.stop();
                    } else {
                        voice.speak(m.text);
                    }
                });
            }
            h.box.setLayoutParams(lp);
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }
    }
}
