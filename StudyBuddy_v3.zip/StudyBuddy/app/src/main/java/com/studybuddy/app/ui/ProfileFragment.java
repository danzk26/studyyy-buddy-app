package com.studybuddy.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.studybuddy.app.R;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Prefs;
import com.studybuddy.app.util.Session;

/** "Me" tab: profile, level, achievements and shortcuts. */
public class ProfileFragment extends Fragment {

    private TextView tvAvatar;
    private TextView tvName;
    private TextView tvUsername;
    private TextView tvLevel;
    private TextView tvStreak;
    private TextView tvAchTitle;
    private TextView tvAch;
    private ProgressBar progressXp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        tvAvatar = v.findViewById(R.id.tv_avatar);
        tvName = v.findViewById(R.id.tv_name);
        tvUsername = v.findViewById(R.id.tv_username);
        tvLevel = v.findViewById(R.id.tv_level);
        tvStreak = v.findViewById(R.id.tv_streak);
        tvAchTitle = v.findViewById(R.id.tv_ach_title);
        tvAch = v.findViewById(R.id.tv_ach);
        progressXp = v.findViewById(R.id.progress_xp);

        v.findViewById(R.id.btn_rename).setOnClickListener(x -> rename());
        v.findViewById(R.id.btn_settings).setOnClickListener(x ->
                startActivity(new Intent(requireContext(), SettingsActivity.class)));
        v.findViewById(R.id.btn_timer).setOnClickListener(x ->
                startActivity(new Intent(requireContext(), TimerActivity.class)));
        v.findViewById(R.id.btn_leaderboard).setOnClickListener(x ->
                startActivity(new Intent(requireContext(), LeaderboardActivity.class)));
        v.findViewById(R.id.btn_logout).setOnClickListener(x -> confirmLogout());
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        final Context appContext = requireContext().getApplicationContext();
        final long uid = Session.userId(appContext);
        final Prefs prefs = new Prefs(appContext);
        String name = Session.displayName(appContext);
        tvAvatar.setText(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase());
        tvName.setText(name);
        tvUsername.setText("@" + Session.username(appContext));
        tvLevel.setText("Level " + prefs.level() + "  •  " + prefs.xp() + " XP");
        progressXp.setProgress(prefs.xpIntoLevel());
        int streak = prefs.streak();
        tvStreak.setText(streak > 0 ? "🔥 " + streak + "-day streak" : "🔥 No streak yet — play today!");

        final int level = prefs.level();
        Async.<int[]>load(() -> {
            StudyDao dao = AppDatabase.get(appContext).dao();
            return new int[]{dao.resultCount(uid), dao.perfectCount(uid), dao.gameCount(uid),
                    dao.ownReviewerCount(uid), dao.userMessageCount(uid)};
        }, s -> {
            if (!isAdded() || s == null) {
                return;
            }
            String[][] list = {
                    {"🌱", "First Steps", "Finish your first quiz or game", s[0] >= 1 ? "1" : ""},
                    {"🔥", "On Fire", "Reach a 3-day streak", streak >= 3 ? "1" : ""},
                    {"📚", "Note Taker", "Create your own reviewer", s[3] >= 1 ? "1" : ""},
                    {"💯", "Perfect Score", "Get every question right in a quiz", s[1] >= 1 ? "1" : ""},
                    {"🎮", "Gamer", "Play a card or catch game", s[2] >= 1 ? "1" : ""},
                    {"🤖", "Curious Mind", "Ask the AI Teacher 5 questions", s[4] >= 5 ? "1" : ""},
                    {"⭐", "Rising Star", "Reach level 5", level >= 5 ? "1" : ""}
            };
            StringBuilder sb = new StringBuilder();
            int done = 0;
            for (String[] a : list) {
                boolean ok = !a[3].isEmpty();
                if (ok) {
                    done++;
                }
                sb.append(ok ? "✅ " : "🔒 ").append(a[0]).append(" ").append(a[1])
                        .append(" — ").append(a[2]).append("\n");
            }
            tvAchTitle.setText("Achievements  " + done + "/" + list.length);
            tvAch.setText(sb.toString().trim());
        });
    }

    private void rename() {
        final Context appContext = requireContext().getApplicationContext();
        final EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setText(Session.displayName(appContext));
        input.setSelection(input.getText().length());
        FrameLayout box = new FrameLayout(requireContext());
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Change your name")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    final String newName = input.getText().toString().trim();
                    if (newName.isEmpty() || newName.length() > 30) {
                        Toast.makeText(appContext, "Enter a name up to 30 characters.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    final long uid = Session.userId(appContext);
                    Session.setDisplayName(appContext, newName);
                    Async.io(() -> AppDatabase.get(appContext).dao().setDisplayName(uid, newName));
                    refresh();
                })
                .show();
    }

    private void confirmLogout() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Log out?")
                .setMessage("Your notes and progress stay saved on this account.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Log out", (d, w) -> {
                    Session.logout(requireContext());
                    Intent i = new Intent(requireContext(), LoginActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                    requireActivity().finish();
                })
                .show();
    }
}
