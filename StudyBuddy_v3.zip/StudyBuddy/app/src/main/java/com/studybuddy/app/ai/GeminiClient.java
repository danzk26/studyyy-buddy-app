package com.studybuddy.app.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Minimal client for Google's Gemini REST API (generateContent). Needs internet and an API key. */
public final class GeminiClient {
    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta/models/";

    private GeminiClient() {
    }

    /** One message of the conversation. role is "user" or "model". */
    public static final class Turn {
        public final String role;
        public final String text;

        public Turn(String role, String text) {
            this.role = role;
            this.text = text;
        }
    }

    public static final class Reply {
        public String text = "";
        public String functionName;
        public JSONObject functionArgs;
    }

    public static final class GeminiException extends Exception {
        public GeminiException(String message) {
            super(message);
        }
    }

    public static Reply generate(String apiKey, String model, String system, List<Turn> turns,
                                 JSONArray tools, double temperature, int maxTokens,
                                 boolean jsonOutput) throws GeminiException {
        if (apiKey == null || apiKey.isEmpty()) {
            throw new GeminiException("No API key yet. Add your Gemini key in Me > Settings.");
        }
        HttpURLConnection conn = null;
        try {
            JSONObject body = new JSONObject();
            if (system != null && !system.isEmpty()) {
                body.put("systemInstruction", new JSONObject()
                        .put("parts", new JSONArray().put(new JSONObject().put("text", system))));
            }
            JSONArray contents = new JSONArray();
            for (Turn t : turns) {
                contents.put(new JSONObject()
                        .put("role", t.role)
                        .put("parts", new JSONArray().put(new JSONObject().put("text", t.text))));
            }
            body.put("contents", contents);
            if (tools != null) {
                body.put("tools", tools);
            }
            JSONObject gen = new JSONObject()
                    .put("temperature", temperature)
                    .put("maxOutputTokens", maxTokens);
            if (jsonOutput) {
                gen.put("responseMimeType", "application/json");
            }
            if (model.contains("2.5-flash")) {
                // Faster answers: skip the long "thinking" phase.
                gen.put("thinkingConfig", new JSONObject().put("thinkingBudget", 0));
            }
            body.put("generationConfig", gen);

            conn = (HttpURLConnection) new URL(BASE + model + ":generateContent").openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("x-goog-api-key", apiKey);
            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload);
            }
            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String response = readAll(in);
            if (code >= 400) {
                throw new GeminiException(friendlyError(code, response, model));
            }
            return parse(response);
        } catch (GeminiException e) {
            throw e;
        } catch (UnknownHostException e) {
            throw new GeminiException("No internet connection. The AI needs to be online.");
        } catch (SocketTimeoutException e) {
            throw new GeminiException("The AI took too long to answer. Please try again.");
        } catch (Exception e) {
            throw new GeminiException("Could not reach the AI: " + e.getMessage());
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static Reply parse(String response) throws Exception {
        JSONObject root = new JSONObject(response);
        JSONArray candidates = root.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            JSONObject feedback = root.optJSONObject("promptFeedback");
            String reason = feedback == null ? "" : feedback.optString("blockReason", "");
            throw new GeminiException(reason.isEmpty()
                    ? "The AI returned an empty answer. Please try again."
                    : "The AI could not answer that (" + reason + ").");
        }
        Reply reply = new Reply();
        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        if (content != null) {
            JSONArray parts = content.optJSONArray("parts");
            if (parts != null) {
                StringBuilder text = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.getJSONObject(i);
                    if (part.has("text")) {
                        text.append(part.getString("text"));
                    }
                    JSONObject call = part.optJSONObject("functionCall");
                    if (call != null && reply.functionName == null) {
                        reply.functionName = call.optString("name");
                        JSONObject args = call.optJSONObject("args");
                        reply.functionArgs = args == null ? new JSONObject() : args;
                    }
                }
                reply.text = text.toString().trim();
            }
        }
        if (reply.text.isEmpty() && reply.functionName == null) {
            throw new GeminiException("The AI returned an empty answer. Please try again.");
        }
        return reply;
    }

    private static String friendlyError(int code, String response, String model) {
        String message = "";
        try {
            message = new JSONObject(response).getJSONObject("error").optString("message", "");
        } catch (Exception ignored) {
            // keep the generic text
        }
        String lower = message.toLowerCase();
        if (code == 400 && (lower.contains("api key") || lower.contains("api_key"))) {
            return "Your API key is not valid. Check it in Me > Settings.";
        }
        if (code == 401 || code == 403) {
            return "The AI refused the request (check your API key and that the Gemini API is enabled).";
        }
        if (code == 404) {
            return "The model \"" + model + "\" was not found. Change the model name in Me > Settings.";
        }
        if (code == 429) {
            return "The AI is rate-limited right now (free-tier limit). Wait a minute and try again.";
        }
        if (code >= 500) {
            return "The AI service is busy. Please try again in a moment.";
        }
        return message.isEmpty() ? "The AI returned an error (" + code + ")." : message;
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) {
            return "";
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
