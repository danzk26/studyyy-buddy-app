package com.studybuddy.app.ui;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.studybuddy.app.R;
import com.studybuddy.app.ai.LocalAI;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Question;
import com.studybuddy.app.data.Reviewer;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.data.Subject;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.DocumentParsers;
import com.studybuddy.app.util.DocumentTextExtractor;

import java.util.ArrayList;
import java.util.List;

/** Lets the user paste notes; the on-device AI summarizes them and generates quiz questions. */
public class AddReviewerActivity extends AppCompatActivity {

    /** Open this screen and immediately show the file chooser. */
    public static final String EXTRA_AUTO_UPLOAD = "auto_upload";

    private static final String[] EMOJIS = {"📘", "🧪", "🌍", "💡", "🎨", "🧮", "⚽", "🎵", "💻", "🌱"};

    private Spinner spinner;
    private TextInputEditText etNewSubject;
    private TextInputEditText etTitle;
    private TextInputEditText etContent;
    private MaterialButton btnSave;
    private MaterialButton btnAiNotes;
    private MaterialButton btnUpload;
    private TextView tvUploadStatus;

    /** The system file chooser. */
    private final ActivityResultLauncher<String[]> filePicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) {
                    readPickedFile(uri);
                }
            });
    private final List<Long> subjectIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reviewer);
        setTitle("Add notes");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        spinner = findViewById(R.id.sp_subject);
        etNewSubject = findViewById(R.id.et_new_subject);
        etTitle = findViewById(R.id.et_title);
        etContent = findViewById(R.id.et_content);
        btnSave = findViewById(R.id.btn_save);
        btnSave.setOnClickListener(v -> save());
        btnAiNotes = findViewById(R.id.btn_ai_notes);
        btnAiNotes.setOnClickListener(v -> writeNotesWithAi());
        btnUpload = findViewById(R.id.btn_upload);
        tvUploadStatus = findViewById(R.id.tv_upload_status);
        btnUpload.setOnClickListener(v -> pickFile());
        if (savedInstanceState == null && getIntent().getBooleanExtra(EXTRA_AUTO_UPLOAD, false)) {
            getWindow().getDecorView().post(this::pickFile);
        }

        final Context appContext = getApplicationContext();
        final long uid0 = com.studybuddy.app.util.Session.userId(appContext);
        Async.<List<Subject>>load(() -> AppDatabase.get(appContext).dao().subjects(uid0), subjects -> {
            if (isFinishing() || isDestroyed() || subjects == null) {
                return;
            }
            List<String> labels = new ArrayList<>();
            for (Subject s : subjects) {
                labels.add(s.emoji + " " + s.name);
                subjectIds.add(s.id);
            }
            spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        });
    }

    private void save() {
        final String title = text(etTitle);
        final String content = text(etContent);
        final String newSubject = text(etNewSubject);
        if (title.isEmpty()) {
            etTitle.setError("Give your notes a title");
            return;
        }
        if (content.length() < 40) {
            etContent.setError("Write a few full sentences so the AI has something to work with");
            return;
        }
        if (newSubject.isEmpty() && subjectIds.isEmpty()) {
            etNewSubject.setError("Create a subject first");
            return;
        }
        final int pos = spinner.getSelectedItemPosition();
        final List<Long> ids = new ArrayList<>(subjectIds);
        final Context appContext = getApplicationContext();
        btnSave.setEnabled(false);
        btnSave.setText("🤖 AI is working…");

        final long uid = com.studybuddy.app.util.Session.userId(appContext);
        Async.<int[]>net(() -> {
            StudyDao dao = AppDatabase.get(appContext).dao();
            long subjectId;
            if (!newSubject.isEmpty()) {
                String emoji = EMOJIS[(int) (System.currentTimeMillis() % EMOJIS.length)];
                Subject created = new Subject(newSubject, emoji);
                created.userId = uid;
                subjectId = dao.insertSubject(created);
            } else {
                subjectId = ids.get(Math.max(0, pos));
            }
            Reviewer r = new Reviewer(subjectId, title, content);
            r.userId = uid;
            r.summary = LocalAI.summarize(content, 3);
            r.id = dao.insertReviewer(r);
            com.studybuddy.app.ai.QuizAI.Generated g = com.studybuddy.app.ai.QuizAI.generate(appContext, r, 10, uid);
            dao.insertQuestions(g.questions);
            return new int[]{g.questions.size(), g.usedOnlineAi ? 1 : 0};
        }, res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            int count = res == null ? 0 : res[0];
            boolean online = res != null && res[1] == 1;
            Toast.makeText(this, count > 0
                    ? "✨ Saved! The " + (online ? "online AI" : "offline AI") + " created " + count + " questions."
                    : "Saved! (Notes were short, so no questions were generated.)", Toast.LENGTH_LONG).show();
            finish();
        });
    }

    private void pickFile() {
        try {
            filePicker.launch(new String[]{"*/*"});
        } catch (Exception e) {
            Toast.makeText(this, "No file chooser is available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    /** Reads the chosen PDF / Word / PowerPoint / text file and fills in the notes box. */
    private void readPickedFile(final Uri uri) {
        final Context appContext = getApplicationContext();
        final String fileName = DocumentTextExtractor.getDisplayName(appContext, uri);
        btnUpload.setEnabled(false);
        tvUploadStatus.setText("⏳ Reading " + fileName + "…");
        Async.<String[]>load(() -> {
            try {
                return new String[]{DocumentTextExtractor.extract(appContext, uri), null};
            } catch (Exception e) {
                String msg = (e instanceof DocumentParsers.UnsupportedDocumentException)
                        ? e.getMessage() : "Could not read this file: " + e.getMessage();
                return new String[]{null, msg};
            }
        }, res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            btnUpload.setEnabled(true);
            if (res == null || res[0] == null) {
                tvUploadStatus.setText("❌ " + (res == null ? "Something went wrong. Please try again." : res[1]));
                return;
            }
            String notes = res[0];
            etContent.setText(notes);
            if (text(etTitle).isEmpty()) {
                etTitle.setText(fileName.replaceAll("(?i)\\.(pdf|docx|pptx|txt|md|csv)$", "")
                        .replace("_", " ").replace("-", " ").trim());
            }
            int words = notes.trim().isEmpty() ? 0 : notes.trim().split("\\s+").length;
            tvUploadStatus.setText("✅ Loaded " + words + " words from " + fileName
                    + ". Pick a subject below, then tap Save.");
        });
    }

    /** Uses the title as the topic and asks the online AI to write the notes. */
    private void writeNotesWithAi() {
        final String topic = text(etTitle);
        if (topic.isEmpty()) {
            etTitle.setError("Type a topic in the title first (for example: The Water Cycle)");
            return;
        }
        final String hint = text(etNewSubject);
        final Context appContext = getApplicationContext();
        btnAiNotes.setEnabled(false);
        btnAiNotes.setText("✨ The AI is writing…");
        Async.<com.studybuddy.app.ai.AiResult<String>>net(
                () -> com.studybuddy.app.ai.NotesAI.write(appContext, topic, hint), res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            btnAiNotes.setEnabled(true);
            btnAiNotes.setText("✨ Write the notes for me (online AI)");
            if (res == null) {
                Toast.makeText(this, "Something went wrong. Please try again.", Toast.LENGTH_LONG).show();
            } else if (!res.ok()) {
                Toast.makeText(this, res.error, Toast.LENGTH_LONG).show();
            } else {
                etContent.setText(res.value);
                Toast.makeText(this, "✅ Notes written! Edit them if you like, then save.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private static String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
