package com.studybuddy.app.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.studybuddy.app.R;
import com.studybuddy.app.ai.AiResult;
import com.studybuddy.app.ai.GeminiClient;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.AppSettings;
import com.studybuddy.app.util.Net;
import com.studybuddy.app.util.Session;
import com.studybuddy.app.util.Voice;

import java.util.ArrayList;
import java.util.List;

/** AI key, AI model and teacher-voice settings. */
public class SettingsActivity extends AppCompatActivity {

    private TextInputEditText etKey;
    private TextInputEditText etModel;
    private MaterialSwitch swVoice;
    private SeekBar seekRate;
    private TextView tvRate;
    private TextView tvStatus;
    private Voice voice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        setTitle("⚙️ Settings");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        etKey = findViewById(R.id.et_key);
        etModel = findViewById(R.id.et_model);
        swVoice = findViewById(R.id.sw_voice);
        seekRate = findViewById(R.id.seek_rate);
        tvRate = findViewById(R.id.tv_rate);
        tvStatus = findViewById(R.id.tv_status);

        etKey.setText(AppSettings.savedApiKey(this));
        etModel.setText(AppSettings.model(this));
        swVoice.setChecked(AppSettings.voiceOn(this));
        int progress = Math.round((AppSettings.speechRate(this) - 0.5f) * 10f);
        seekRate.setMax(15);
        seekRate.setProgress(Math.max(0, Math.min(15, progress)));
        showRate();
        seekRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                showRate();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });

        findViewById(R.id.btn_get_key).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")));
            } catch (Exception e) {
                Toast.makeText(this, "Open aistudio.google.com/app/apikey in your browser.", Toast.LENGTH_LONG).show();
            }
        });
        findViewById(R.id.btn_save).setOnClickListener(v -> {
            save();
            Toast.makeText(this, "✅ Settings saved", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btn_test).setOnClickListener(v -> testConnection());
        findViewById(R.id.btn_test_voice).setOnClickListener(v -> testVoice());
        findViewById(R.id.btn_clear_chat).setOnClickListener(v -> confirmClearChat());
    }

    private float rate() {
        return 0.5f + seekRate.getProgress() / 10f;
    }

    private void showRate() {
        tvRate.setText(String.format(java.util.Locale.US, "Speaking speed: %.1fx", rate()));
    }

    private void save() {
        AppSettings.setApiKey(this, text(etKey));
        String model = text(etModel);
        AppSettings.setModel(this, model.isEmpty() ? AppSettings.DEFAULT_MODEL : model);
        AppSettings.setVoiceOn(this, swVoice.isChecked());
        AppSettings.setSpeechRate(this, rate());
    }

    private void testConnection() {
        save();
        if (!Net.isOnline(this)) {
            tvStatus.setText("❌ No internet connection.");
            return;
        }
        if (!AppSettings.hasApiKey(this)) {
            tvStatus.setText("❌ Paste your API key first.");
            return;
        }
        tvStatus.setText("⏳ Testing the connection…");
        final Context appContext = getApplicationContext();
        Async.<AiResult<String>>net(() -> {
            List<GeminiClient.Turn> turns = new ArrayList<>();
            turns.add(new GeminiClient.Turn("user", "Reply with one short friendly sentence saying you are ready to teach."));
            try {
                GeminiClient.Reply r = GeminiClient.generate(AppSettings.apiKey(appContext),
                        AppSettings.model(appContext), "You are a friendly teacher.", turns, null, 0.5, 200, false);
                return AiResult.ok(r.text);
            } catch (GeminiClient.GeminiException e) {
                return AiResult.fail(e.getMessage());
            }
        }, res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            if (res == null) {
                tvStatus.setText("❌ Something went wrong.");
            } else if (res.ok()) {
                tvStatus.setText("✅ Connected! The AI says: " + res.value);
            } else {
                tvStatus.setText("❌ " + res.error);
            }
        });
    }

    private void testVoice() {
        if (voice == null) {
            voice = new Voice(this);
        }
        voice.setRate(rate());
        voice.speak("Hello! I am your AI teacher. This is how I sound.");
    }

    private void confirmClearChat() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Clear teacher chat?")
                .setMessage("This deletes your conversation history with the AI Teacher.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    final Context appContext = getApplicationContext();
                    final long uid = Session.userId(appContext);
                    Async.io(() -> AppDatabase.get(appContext).dao().clearChat(uid));
                    Toast.makeText(this, "Chat cleared", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private static String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (voice != null) {
            voice.shutdown();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
