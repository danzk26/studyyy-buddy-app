package com.studybuddy.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.studybuddy.app.R;
import com.studybuddy.app.data.Question;

import java.util.ArrayList;
import java.util.List;

/**
 * A 2D arcade game drawn on a Canvas. A question is shown above; four answers fall from the sky.
 * Drag your finger to move the fox and catch the correct answer. Wrong catches cost a heart,
 * and the answers fall faster every round.
 */
public class CatchGameView extends View {

    public interface Listener {
        void onQuestion(Question q, int number, int total);

        void onStats(int score, int lives, int combo);

        void onFeedback(String message, boolean good);

        void onGameOver(int correct, int played, int xp, boolean finishedAll);
    }

    private enum State { IDLE, FALLING, REVEAL, OVER }

    private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lanePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emojiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private final float density;
    private final int colorBubble;
    private final int colorGood;
    private final int colorBad;
    private final int colorBg;

    private List<Question> questions = new ArrayList<>();
    private Listener listener;
    private State state = State.IDLE;

    private int qIndex = -1;
    private int score = 0;
    private int lives = 3;
    private int combo = 0;
    private int bestCombo = 0;
    private int xp = 0;
    private int played = 0;

    private final float[] bubbleY = new float[4];
    private final StaticLayout[] layouts = new StaticLayout[4];
    private float speed;
    private float playerX;
    private float targetX;
    private int caught = -1;
    private float revealTimer = 0f;

    private boolean running = false;
    private boolean pendingStart = false;
    private long lastNanos = 0;

    private float laneW;
    private float bubbleW;
    private float bubbleH;
    private float playerSize;

    public CatchGameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = context.getResources().getDisplayMetrics().density;
        colorBubble = ContextCompat.getColor(context, R.color.primary);
        colorGood = ContextCompat.getColor(context, R.color.good);
        colorBad = ContextCompat.getColor(context, R.color.bad);
        colorBg = ContextCompat.getColor(context, R.color.bg);

        textPaint.setColor(0xFFFFFFFF);
        textPaint.setTextSize(14f * context.getResources().getDisplayMetrics().scaledDensity);
        textPaint.setFakeBoldText(true);
        lanePaint.setColor(0x14000000);
        lanePaint.setStrokeWidth(2f * density);
        glowPaint.setColor(0x33000000);
        emojiPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setQuestions(List<Question> list) {
        questions = list;
    }

    // ------------------------------------------------------------------
    // Game control
    // ------------------------------------------------------------------
    public void start() {
        score = 0;
        lives = 3;
        combo = 0;
        bestCombo = 0;
        xp = 0;
        played = 0;
        qIndex = -1;
        if (getWidth() == 0) {
            pendingStart = true; // wait until the view has a size
            return;
        }
        nextQuestion();
        resume();
    }

    public void pause() {
        running = false;
    }

    public void resume() {
        if (state == State.IDLE || state == State.OVER || running || getWidth() == 0) {
            return;
        }
        running = true;
        lastNanos = System.nanoTime();
        postOnAnimation(frame);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        laneW = w / 4f;
        bubbleW = laneW - 10f * density;
        bubbleH = 84f * density;
        playerSize = 56f * density;
        if (playerX == 0f) {
            playerX = w / 2f;
            targetX = playerX;
        }
        if (pendingStart) {
            pendingStart = false;
            nextQuestion();
            resume();
        }
    }

    private void nextQuestion() {
        qIndex++;
        if (qIndex >= questions.size() || lives <= 0) {
            endGame(qIndex >= questions.size() && lives > 0);
            return;
        }
        Question q = questions.get(qIndex);
        String[] options = q.options();
        int textW = (int) (bubbleW - 14f * density);
        for (int i = 0; i < 4; i++) {
            bubbleY[i] = -bubbleH - 4f * density;
            layouts[i] = StaticLayout.Builder.obtain(options[i], 0, options[i].length(), textPaint, Math.max(40, textW))
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(4)
                    .setEllipsize(TextUtils.TruncateAt.END)
                    .build();
        }
        caught = -1;
        speed = Math.min(260f, 105f + qIndex * 9f) * density;
        state = State.FALLING;
        if (listener != null) {
            listener.onQuestion(q, qIndex + 1, questions.size());
            listener.onStats(score, lives, combo);
        }
    }

    private void endGame(boolean finishedAll) {
        state = State.OVER;
        running = false;
        invalidate();
        if (listener != null) {
            listener.onGameOver(score, played, xp, finishedAll);
        }
    }

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - lastNanos) / 1_000_000_000f);
            lastNanos = now;
            step(dt);
            invalidate();
            if (running) {
                postOnAnimation(this);
            }
        }
    };

    private void step(float dt) {
        playerX += (targetX - playerX) * Math.min(1f, dt * 14f);
        if (state == State.FALLING) {
            Question q = questions.get(qIndex);
            float playerTop = getHeight() - playerSize - 12f * density;
            boolean allGone = true;
            for (int i = 0; i < 4; i++) {
                bubbleY[i] += speed * dt;
                float bottom = bubbleY[i] + bubbleH;
                float centerX = i * laneW + laneW / 2f;
                if (bottom >= playerTop && bubbleY[i] < playerTop + playerSize
                        && Math.abs(centerX - playerX) < playerSize / 2f + bubbleW * 0.30f) {
                    resolve(i, q);
                    return;
                }
                if (bubbleY[i] < getHeight()) {
                    allGone = false;
                }
            }
            if (allGone) {
                missed(q);
            }
        } else if (state == State.REVEAL) {
            revealTimer -= dt;
            if (revealTimer <= 0f) {
                nextQuestion();
            }
        }
    }

    private void resolve(int i, Question q) {
        caught = i;
        played++;
        boolean right = i == q.correct;
        if (right) {
            score++;
            combo++;
            bestCombo = Math.max(bestCombo, combo);
            xp += 10 + (combo >= 3 ? 5 : 0);
            if (listener != null) {
                listener.onFeedback("✅ Nice catch! " + q.explanation, true);
            }
        } else {
            lives--;
            combo = 0;
            if (listener != null) {
                listener.onFeedback("❌ Oops! The answer was: " + q.correctText(), false);
            }
        }
        if (listener != null) {
            listener.onStats(score, lives, combo);
        }
        state = State.REVEAL;
        revealTimer = right ? 1.0f : 1.8f;
    }

    private void missed(Question q) {
        played++;
        lives--;
        combo = 0;
        caught = -1;
        if (listener != null) {
            listener.onFeedback("💨 Too slow! The answer was: " + q.correctText(), false);
            listener.onStats(score, lives, combo);
        }
        state = State.REVEAL;
        revealTimer = 1.8f;
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(colorBg);
        if (laneW == 0f) {
            return;
        }
        for (int i = 1; i < 4; i++) {
            canvas.drawLine(i * laneW, 0, i * laneW, getHeight(), lanePaint);
        }
        if ((state == State.FALLING || state == State.REVEAL) && qIndex >= 0 && qIndex < questions.size()) {
            Question q = questions.get(qIndex);
            for (int i = 0; i < 4; i++) {
                float left = i * laneW + (laneW - bubbleW) / 2f;
                rect.set(left, bubbleY[i], left + bubbleW, bubbleY[i] + bubbleH);
                int color = colorBubble;
                if (state == State.REVEAL) {
                    if (i == q.correct) {
                        color = colorGood;
                    } else if (i == caught) {
                        color = colorBad;
                    }
                }
                glowPaint.setAlpha(40);
                canvas.drawRoundRect(rect.left, rect.top + 4f * density, rect.right, rect.bottom + 4f * density,
                        18f * density, 18f * density, glowPaint);
                bubblePaint.setColor(color);
                canvas.drawRoundRect(rect, 18f * density, 18f * density, bubblePaint);
                StaticLayout sl = layouts[i];
                if (sl != null) {
                    canvas.save();
                    canvas.translate(left + 7f * density, bubbleY[i] + (bubbleH - sl.getHeight()) / 2f);
                    sl.draw(canvas);
                    canvas.restore();
                }
            }
        }
        // the fox
        emojiPaint.setTextSize(playerSize * 0.95f);
        float baseY = getHeight() - 16f * density;
        canvas.drawText("🦊", playerX, baseY, emojiPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                targetX = Math.max(playerSize / 2f, Math.min(getWidth() - playerSize / 2f, e.getX()));
                return true;
            case MotionEvent.ACTION_UP:
                performClick();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    public int getBestCombo() {
        return bestCombo;
    }
}
