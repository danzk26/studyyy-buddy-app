package com.studybuddy.app.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.studybuddy.app.R;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Question;
import com.studybuddy.app.data.QuizResult;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Prefs;
import com.studybuddy.app.util.Session;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Card Quest: a question and FOUR FACE-UP answer cards (A, B, C, D). Tap the card you think is
 * right and it flips over in 3D to show if you were correct. Stuck? Use a power-up:
 * a Hint (a clue + one wrong card crossed out), 50/50 (two wrong cards crossed out) or Skip.
 * Get 3 correct in a row to win a free Hint. You have 5 hearts and there is no timer.
 */
public class CardGameActivity extends AppCompatActivity {

    public static final String EXTRA_SUBJECT = "subject";
    private static final int ROUNDS = 8;
    private static final int MAX_LIVES = 5;

    private final MaterialCardView[] cards = new MaterialCardView[4];
    private final TextView[] tags = new TextView[4];
    private final TextView[] faces = new TextView[4];
    private final boolean[] crossedOut = new boolean[4];

    private List<Question> questions;
    private int index = 0;
    private int score = 0;
    private int lives = MAX_LIVES;
    private int combo = 0;
    private int bestCombo = 0;
    private int xp = 0;
    private int played = 0;
    private int hintsLeft = 3;
    private int fiftyLeft = 1;
    private int skipsLeft = 1;
    private boolean locked = true;
    private boolean helpedThisRound = false;
    private long subjectId;

    private TextView tvScore;
    private TextView tvLives;
    private TextView tvRound;
    private TextView tvQuestion;
    private TextView tvHint;
    private TextView tvFeedback;
    private MaterialButton btnNext;
    private MaterialButton btnHint;
    private MaterialButton btnFifty;
    private MaterialButton btnSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_game);
        setTitle("🎴 Card Quest");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        subjectId = getIntent().getLongExtra(EXTRA_SUBJECT, 0);
        tvScore = findViewById(R.id.tv_score);
        tvLives = findViewById(R.id.tv_lives);
        tvRound = findViewById(R.id.tv_round);
        tvQuestion = findViewById(R.id.tv_question);
        tvHint = findViewById(R.id.tv_hint);
        tvFeedback = findViewById(R.id.tv_feedback);
        btnNext = findViewById(R.id.btn_next);
        btnHint = findViewById(R.id.btn_hint);
        btnFifty = findViewById(R.id.btn_5050);
        btnSkip = findViewById(R.id.btn_skip);

        int[] cardIds = {R.id.card0, R.id.card1, R.id.card2, R.id.card3};
        int[] tagIds = {R.id.tag0, R.id.tag1, R.id.tag2, R.id.tag3};
        int[] faceIds = {R.id.face0, R.id.face1, R.id.face2, R.id.face3};
        float distance = 8000f * getResources().getDisplayMetrics().density;
        for (int i = 0; i < 4; i++) {
            final int pick = i;
            cards[i] = findViewById(cardIds[i]);
            tags[i] = findViewById(tagIds[i]);
            faces[i] = findViewById(faceIds[i]);
            cards[i].setCameraDistance(distance); // makes the flip look 3D
            cards[i].setOnClickListener(v -> onPick(pick));
        }
        btnNext.setOnClickListener(v -> {
            index++;
            if (index >= questions.size() || lives <= 0) {
                finishGame();
            } else {
                dealRound();
            }
        });
        btnHint.setOnClickListener(v -> useHint());
        btnFifty.setOnClickListener(v -> useFifty());
        btnSkip.setOnClickListener(v -> useSkip());

        final Context appContext = getApplicationContext();
        final long uid = Session.userId(appContext);
        Async.<List<Question>>load(() -> AppDatabase.get(appContext).dao().randomQuestions(subjectId, uid, ROUNDS), list -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            if (list == null || list.isEmpty()) {
                Toast.makeText(this, "No questions yet — add notes in the Library first!", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            questions = list;
            dealRound();
            showTutorialOnce();
        });
    }

    private int color(int res) {
        return ContextCompat.getColor(this, res);
    }

    private float dp(int v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private void showTutorialOnce() {
        final SharedPreferences flags = getSharedPreferences("flags", MODE_PRIVATE);
        if (flags.getBoolean("card_quest_tutorial", false)) {
            return;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle("🎴 How to play Card Quest")
                .setMessage("1️⃣  Read the question at the top.\n\n"
                        + "2️⃣  All four answer cards are face up. Tap the one you think is right.\n\n"
                        + "3️⃣  The card flips over in 3D: green means correct, red means wrong.\n\n"
                        + "4️⃣  Stuck? Use a power-up:\n"
                        + "     💡 Hint = a clue + one wrong card crossed out\n"
                        + "     ✂️ 50/50 = two wrong cards crossed out\n"
                        + "     ⏭ Skip = next question, no penalty\n\n"
                        + "🎁  3 correct in a row wins a free Hint!\n"
                        + "❤️  You have 5 hearts. There is no timer.")
                .setPositiveButton("Got it, let's play!", (d, w) -> flags.edit().putBoolean("card_quest_tutorial", true).apply())
                .setCancelable(false)
                .show();
    }

    private void updateHud() {
        tvScore.setText("⭐ " + score + (combo >= 2 ? "  🔥x" + combo : ""));
        StringBuilder hearts = new StringBuilder();
        for (int i = 0; i < MAX_LIVES; i++) {
            hearts.append(i < lives ? "❤️" : "🖤");
        }
        tvLives.setText(hearts.toString());
    }

    private void updatePowerUps() {
        int remaining = 0;
        for (boolean c : crossedOut) {
            if (!c) {
                remaining++;
            }
        }
        btnHint.setText("💡 Hint (" + hintsLeft + ")");
        btnFifty.setText("✂️ 50/50 (" + fiftyLeft + ")");
        btnSkip.setText("⏭ Skip (" + skipsLeft + ")");
        btnHint.setEnabled(!locked && hintsLeft > 0 && !helpedThisRound);
        btnFifty.setEnabled(!locked && fiftyLeft > 0 && remaining > 2);
        btnSkip.setEnabled(!locked && skipsLeft > 0);
    }

    private void styleNormal(int i) {
        MaterialCardView c = cards[i];
        c.setCardBackgroundColor(color(R.color.card));
        c.setStrokeColor(color(R.color.primary));
        c.setStrokeWidth((int) dp(2));
        tags[i].setTextColor(color(R.color.primary));
        faces[i].setTextColor(color(R.color.text));
        faces[i].setPaintFlags(faces[i].getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        c.setAlpha(1f);
    }

    /** Shows the next question with all four answer cards face up. */
    private void dealRound() {
        final Question q = questions.get(index);
        String[] options = q.options();
        tvRound.setText("Round " + (index + 1) + " / " + questions.size());
        tvQuestion.setText(q.question);
        tvHint.setText(index == 0
                ? "👆 Tap the card you think is correct. Stuck? Use a power-up below!"
                : "👆 Tap the card you think is correct.");
        tvFeedback.setText("");
        btnNext.setVisibility(View.INVISIBLE);
        helpedThisRound = false;
        String[] letters = {"A", "B", "C", "D"};
        for (int i = 0; i < 4; i++) {
            crossedOut[i] = false;
            MaterialCardView c = cards[i];
            c.animate().cancel();
            c.setRotationY(0f);
            c.setEnabled(true);
            styleNormal(i);
            tags[i].setText(letters[i]);
            faces[i].setText(options[i]);
            // deal-in animation
            c.setAlpha(0f);
            c.setTranslationY(120f);
            c.animate().alpha(1f).translationY(0f).setStartDelay(i * 80L).setDuration(260).start();
        }
        locked = false;
        updateHud();
        updatePowerUps();
    }

    // ------------------------------------------------------------------
    // Power-ups
    // ------------------------------------------------------------------
    private void useHint() {
        if (locked || hintsLeft <= 0 || helpedThisRound) {
            return;
        }
        Question q = questions.get(index);
        hintsLeft--;
        helpedThisRound = true;
        String answer = q.correctText().trim();
        int words = answer.isEmpty() ? 1 : answer.split("\\s+").length;
        String first = answer.isEmpty() ? "?" : answer.substring(0, 1).toUpperCase();
        crossOutRandomWrong(1);
        tvHint.setText("💡 Clue: the answer starts with “" + first + "”, has " + words
                + (words == 1 ? " word" : " words") + " and " + answer.length()
                + " characters. I crossed out one wrong card for you.");
        updatePowerUps();
    }

    private void useFifty() {
        if (locked || fiftyLeft <= 0) {
            return;
        }
        fiftyLeft--;
        helpedThisRound = true;
        crossOutRandomWrong(2);
        tvHint.setText("✂️ Two wrong cards are crossed out. Only two are left, so it's a coin flip at worst!");
        updatePowerUps();
    }

    private void useSkip() {
        if (locked || skipsLeft <= 0) {
            return;
        }
        skipsLeft--;
        Toast.makeText(this, "Skipped — no penalty", Toast.LENGTH_SHORT).show();
        index++;
        if (index >= questions.size()) {
            finishGame();
        } else {
            dealRound();
        }
    }

    private void crossOutRandomWrong(int count) {
        Question q = questions.get(index);
        List<Integer> options = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            if (i != q.correct && !crossedOut[i]) {
                options.add(i);
            }
        }
        Collections.shuffle(options);
        for (int n = 0; n < count && n < options.size(); n++) {
            int i = options.get(n);
            crossedOut[i] = true;
            cards[i].setEnabled(false);
            cards[i].animate().alpha(0.35f).setStartDelay(0).setDuration(250).start();
            faces[i].setPaintFlags(faces[i].getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    // ------------------------------------------------------------------
    // Answering
    // ------------------------------------------------------------------
    private void onPick(int choice) {
        if (locked || crossedOut[choice]) {
            return;
        }
        locked = true;
        final Question q = questions.get(index);
        played++;
        boolean right = choice == q.correct;
        String[] options = q.options();
        StringBuilder feedback = new StringBuilder();
        if (right) {
            score++;
            combo++;
            bestCombo = Math.max(bestCombo, combo);
            xp += (helpedThisRound ? 5 : 10) + (combo >= 3 ? 5 : 0);
            flip(choice, options[choice], true, "CORRECT", 0);
            feedback.append("✅ Correct! ").append(q.explanation);
            if (combo % 3 == 0) {
                hintsLeft++;
                feedback.append("\n\n🎁 Streak bonus: you won a free 💡 Hint!");
            }
        } else {
            lives--;
            combo = 0;
            flip(choice, options[choice], false, "NOT THIS ONE", 0);
            flip(q.correct, options[q.correct], true, "THE ANSWER", 650);
            feedback.append("❌ Not quite. The answer is: ").append(q.correctText())
                    .append("\n\n").append(q.explanation);
        }
        tvFeedback.setText(feedback.toString());
        tvHint.setText(right ? "🎉 Nice one!" : "No worries — now you know it. Keep going!");
        updateHud();
        updatePowerUps();
        boolean last = index >= questions.size() - 1 || lives <= 0;
        btnNext.setText(last ? "Finish 🏁" : "Next round ➜");
        btnNext.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed()) {
                btnNext.setVisibility(View.VISIBLE);
            }
        }, right ? 500 : 1100);
    }

    /** Turns one card around in 3D and shows the result on its back. */
    private void flip(final int i, final String answer, final boolean good, final String label, long delay) {
        final MaterialCardView c = cards[i];
        c.animate().setStartDelay(delay).rotationY(90f).setDuration(170).withEndAction(() -> {
            c.setCardBackgroundColor(color(good ? R.color.good : R.color.bad));
            c.setStrokeWidth(0);
            tags[i].setText(label);
            tags[i].setTextColor(color(R.color.white));
            faces[i].setText((good ? "✅ " : "❌ ") + answer);
            faces[i].setTextColor(color(R.color.white));
            c.setRotationY(-90f);
            c.animate().setStartDelay(0).rotationY(0f).setDuration(170).start();
        }).start();
    }

    private void finishGame() {
        final int total = Math.max(1, played);
        final Context appContext = getApplicationContext();
        final QuizResult result = new QuizResult(subjectId, "cards", score, total, xp);
        result.userId = Session.userId(appContext);
        Prefs prefs = new Prefs(appContext);
        int levelBefore = prefs.level();
        prefs.addXp(xp);
        prefs.markStudiedToday();
        boolean levelUp = prefs.level() > levelBefore;
        Async.io(() -> AppDatabase.get(appContext).dao().insertResult(result));

        String verdict = lives <= 0 ? "💔 Out of hearts!" : score == total ? "🏆 Perfect run!" : "🎉 Quest complete!";
        String message = "You got " + score + " correct out of " + total + "\n\n"
                + "⭐ +" + xp + " XP\n🔥 Best streak: x" + bestCombo
                + (levelUp ? "\n\n🆙 LEVEL UP! You're now level " + prefs.level() + "!" : "");
        new MaterialAlertDialogBuilder(this)
                .setTitle(verdict)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Done", (d, w) -> finish())
                .setNegativeButton("Play again", (d, w) -> {
                    startActivity(getIntent());
                    finish();
                })
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
