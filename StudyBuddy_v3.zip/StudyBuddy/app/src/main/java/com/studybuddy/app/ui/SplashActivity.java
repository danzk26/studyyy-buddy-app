package com.studybuddy.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.studybuddy.app.MainActivity;
import com.studybuddy.app.R;
import com.studybuddy.app.util.Session;

/** Shows the logo for a moment, then opens the app (if logged in) or the login screen. */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            Class<?> next = Session.isLoggedIn(this) ? MainActivity.class : LoginActivity.class;
            startActivity(new Intent(this, next));
            finish();
        }, 1100);
    }
}
