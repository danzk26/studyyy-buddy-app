package com.studybuddy.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

/**
 * All database access. "uid" is the logged-in user's id. Built-in content has userId = 0 and
 * is visible to everyone, so every query uses "userId IN (0, :uid)".
 */
@Dao
public interface StudyDao {

    // ---- Users ----
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insertUser(User u);

    @Query("SELECT * FROM User WHERE username = :name COLLATE NOCASE LIMIT 1")
    User userByName(String name);

    @Query("SELECT * FROM User WHERE id = :id")
    User user(long id);

    @Query("UPDATE User SET xp = :xp WHERE id = :id")
    void setUserXp(long id, int xp);

    @Query("UPDATE User SET displayName = :name WHERE id = :id")
    void setDisplayName(long id, String name);

    @Query("SELECT * FROM User ORDER BY xp DESC, displayName COLLATE NOCASE LIMIT :n")
    List<User> topUsers(int n);

    // ---- Subjects ----
    @Insert
    long insertSubject(Subject s);

    @Query("SELECT * FROM Subject WHERE userId IN (0, :uid) ORDER BY name")
    List<Subject> subjects(long uid);

    @Query("SELECT COUNT(*) FROM Subject")
    int subjectCount();

    @Query("SELECT * FROM Subject WHERE id = :id")
    Subject subject(long id);

    @Query("SELECT * FROM Subject WHERE name = :name COLLATE NOCASE AND userId IN (0, :uid) LIMIT 1")
    Subject subjectByName(String name, long uid);

    // ---- Reviewers ----
    @Insert
    long insertReviewer(Reviewer r);

    @Query("SELECT * FROM Reviewer WHERE userId IN (0, :uid) ORDER BY createdAt DESC")
    List<Reviewer> reviewers(long uid);

    @Query("SELECT COUNT(*) FROM Reviewer WHERE userId = :uid")
    int ownReviewerCount(long uid);

    @Query("SELECT * FROM Reviewer WHERE id = :id")
    Reviewer reviewer(long id);

    @Query("UPDATE Reviewer SET summary = :summary WHERE id = :id")
    void setSummary(long id, String summary);

    @Query("DELETE FROM Reviewer WHERE id = :id")
    void deleteReviewerById(long id);

    // ---- Questions ----
    @Insert
    void insertQuestions(List<Question> questions);

    @Insert
    long insertQuestion(Question q);

    @Query("SELECT * FROM Question WHERE (:sid = 0 OR subjectId = :sid) AND userId IN (0, :uid) ORDER BY RANDOM() LIMIT :n")
    List<Question> randomQuestions(long sid, long uid, int n);

    @Query("SELECT * FROM Question WHERE reviewerId = :rid AND userId IN (0, :uid) ORDER BY RANDOM() LIMIT :n")
    List<Question> randomForReviewer(long rid, long uid, int n);

    @Query("SELECT COUNT(*) FROM Question WHERE userId IN (0, :uid)")
    int questionCount(long uid);

    @Query("SELECT COUNT(*) FROM Question WHERE reviewerId = :rid AND userId IN (0, :uid)")
    int questionCountFor(long rid, long uid);

    @Query("DELETE FROM Question WHERE reviewerId = :rid")
    void deleteQuestionsFor(long rid);

    @Query("DELETE FROM Question WHERE reviewerId = :rid AND source <> 0 AND userId = :uid")
    void deleteGeneratedQuestionsFor(long rid, long uid);

    // ---- Results ----
    @Insert
    void insertResult(QuizResult r);

    @Query("SELECT * FROM QuizResult WHERE userId = :uid ORDER BY timestamp DESC LIMIT :n")
    List<QuizResult> recentResults(long uid, int n);

    @Query("SELECT COUNT(*) FROM QuizResult WHERE userId = :uid")
    int resultCount(long uid);

    @Query("SELECT COUNT(*) FROM QuizResult WHERE userId = :uid AND total > 0 AND score = total")
    int perfectCount(long uid);

    @Query("SELECT COUNT(*) FROM QuizResult WHERE userId = :uid AND mode IN ('cards', 'catch')")
    int gameCount(long uid);

    // ---- Chat ----
    @Insert
    void insertChat(ChatMessage m);

    @Query("SELECT * FROM (SELECT * FROM ChatMessage WHERE userId = :uid ORDER BY id DESC LIMIT :n) ORDER BY id ASC")
    List<ChatMessage> chat(long uid, int n);

    @Query("SELECT COUNT(*) FROM ChatMessage WHERE userId = :uid AND fromUser = 1")
    int userMessageCount(long uid);

    @Query("DELETE FROM ChatMessage WHERE userId = :uid")
    void clearChat(long uid);
}
