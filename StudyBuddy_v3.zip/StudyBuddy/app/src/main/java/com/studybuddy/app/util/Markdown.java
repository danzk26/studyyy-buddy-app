package com.studybuddy.app.util;

import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;

/** Very small markdown renderer for AI replies: headings, **bold**, `code` and bullet lists. */
public final class Markdown {
    private Markdown() {
    }

    public static CharSequence render(String markdown) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        if (markdown == null) {
            return out;
        }
        String[] lines = markdown.replace("\r", "").split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            boolean heading = false;
            if (line.matches("^\\s{0,3}#{1,6}\\s+.*")) {
                line = line.replaceFirst("^\\s{0,3}#{1,6}\\s+", "");
                heading = true;
            } else if (line.matches("^\\s*[-*+]\\s+.*")) {
                line = line.replaceFirst("^\\s*[-*+]\\s+", "• ");
            }
            int start = out.length();
            appendInline(out, line);
            if (heading) {
                out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (i < lines.length - 1) {
                out.append('\n');
            }
        }
        return out;
    }

    private static void appendInline(SpannableStringBuilder out, String s) {
        int i = 0;
        while (i < s.length()) {
            if (s.startsWith("**", i)) {
                int end = s.indexOf("**", i + 2);
                if (end > i + 2) {
                    int st = out.length();
                    out.append(s, i + 2, end);
                    out.setSpan(new StyleSpan(Typeface.BOLD), st, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = end + 2;
                    continue;
                }
            }
            if (s.charAt(i) == '`') {
                int end = s.indexOf('`', i + 1);
                if (end > i + 1) {
                    int st = out.length();
                    out.append(s, i + 1, end);
                    out.setSpan(new TypefaceSpan("monospace"), st, out.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    i = end + 1;
                    continue;
                }
            }
            out.append(s.charAt(i));
            i++;
        }
    }
}
