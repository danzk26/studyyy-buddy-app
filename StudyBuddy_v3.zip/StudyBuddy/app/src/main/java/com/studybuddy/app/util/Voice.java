package com.studybuddy.app.util;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The teacher's voice, using the phone's built-in text-to-speech engine. */
public final class Voice {
    private TextToSpeech tts;
    private volatile boolean ready = false;
    private float rate;
    private String pending;
    private int counter = 0;

    public Voice(Context context) {
        rate = AppSettings.speechRate(context);
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS || tts == null) {
                return;
            }
            int r = tts.setLanguage(Locale.getDefault());
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US);
            }
            tts.setSpeechRate(rate);
            tts.setPitch(1.0f);
            ready = true;
            if (pending != null) {
                String p = pending;
                pending = null;
                speak(p);
            }
        });
    }

    public void setRate(float newRate) {
        rate = newRate;
        if (tts != null && ready) {
            tts.setSpeechRate(newRate);
        }
    }

    /** Reads text aloud (markdown symbols and emoji are removed first). */
    public void speak(String text) {
        if (tts == null) {
            return;
        }
        String clean = forSpeech(text);
        if (clean.isEmpty()) {
            return;
        }
        if (!ready) {
            pending = text;
            return;
        }
        boolean first = true;
        for (String chunk : chunks(clean, 3000)) {
            tts.speak(chunk, first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "sb" + (counter++));
            first = false;
        }
    }

    public void stop() {
        pending = null;
        if (tts != null && ready) {
            tts.stop();
        }
    }

    public boolean isSpeaking() {
        return tts != null && ready && tts.isSpeaking();
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        ready = false;
    }

    static String forSpeech(String s) {
        if (s == null) {
            return "";
        }
        s = s.replaceAll("```[\\s\\S]*?```", " ");
        s = s.replaceAll("[*_`#>]+", "");
        s = s.replaceAll("[\\p{So}\\p{Cn}\\uFE0F\\u200D]", "");
        s = s.replace("•", ",");
        s = s.replaceAll("(?m)^\\s*[-+]\\s+", "");
        s = s.replaceAll("\\s*\\n+\\s*", ". ");
        s = s.replaceAll("\\.\\s*\\.", ".");
        s = s.replaceAll("\\s{2,}", " ");
        return s.trim();
    }

    static List<String> chunks(String text, int max) {
        List<String> out = new ArrayList<>();
        String rest = text;
        while (rest.length() > max) {
            int cut = rest.lastIndexOf(". ", max);
            if (cut < max / 2) {
                cut = rest.lastIndexOf(' ', max);
            }
            if (cut < 1) {
                cut = max;
            }
            out.add(rest.substring(0, cut + 1).trim());
            rest = rest.substring(cut + 1).trim();
        }
        if (!rest.isEmpty()) {
            out.add(rest);
        }
        return out;
    }
}
