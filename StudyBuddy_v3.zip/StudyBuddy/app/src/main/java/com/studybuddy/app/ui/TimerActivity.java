package com.studybuddy.app.ui;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.studybuddy.app.R;
import com.studybuddy.app.util.Prefs;

import java.util.Locale;

/** Pomodoro study timer: focus sessions earn XP and keep your streak alive. */
public class TimerActivity extends AppCompatActivity {

    private static final int BREAK_MINUTES = 5;
    private static final int FOCUS_XP = 15;

    private TextView tvMode;
    private TextView tvTime;
    private TextView tvMinutes;
    private TextView tvDone;
    private MaterialButton btnStart;
    private MaterialButton btnSwitch;
    private CountDownTimer timer;

    private boolean focus = true;
    private boolean running = false;
    private int focusMinutes = 25;
    private long remainingMs = 25 * 60 * 1000L;
    private int sessionsDone = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        setTitle("⏱️ Study Timer");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        tvMode = findViewById(R.id.tv_mode);
        tvTime = findViewById(R.id.tv_time);
        tvMinutes = findViewById(R.id.tv_minutes);
        tvDone = findViewById(R.id.tv_done);
        btnStart = findViewById(R.id.btn_start);
        btnSwitch = findViewById(R.id.btn_switch);

        btnStart.setOnClickListener(v -> toggle());
        findViewById(R.id.btn_reset).setOnClickListener(v -> reset());
        btnSwitch.setOnClickListener(v -> {
            if (!running) {
                focus = !focus;
                reset();
            }
        });
        findViewById(R.id.btn_minus).setOnClickListener(v -> changeMinutes(-5));
        findViewById(R.id.btn_plus).setOnClickListener(v -> changeMinutes(5));
        reset();
    }

    private void changeMinutes(int delta) {
        if (running) {
            return;
        }
        focusMinutes = Math.max(5, Math.min(60, focusMinutes + delta));
        if (focus) {
            reset();
        } else {
            showMinutes();
        }
    }

    private int currentMinutes() {
        return focus ? focusMinutes : BREAK_MINUTES;
    }

    private void showMinutes() {
        tvMinutes.setText("Focus length: " + focusMinutes + " min   •   Break: " + BREAK_MINUTES + " min");
    }

    private void toggle() {
        if (running) {
            pause();
        } else {
            start();
        }
    }

    private void start() {
        running = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        btnStart.setText("⏸ Pause");
        timer = new CountDownTimer(remainingMs, 250) {
            @Override
            public void onTick(long ms) {
                remainingMs = ms;
                showTime();
            }

            @Override
            public void onFinish() {
                remainingMs = 0;
                showTime();
                onSessionFinished();
            }
        }.start();
    }

    private void pause() {
        running = false;
        if (timer != null) {
            timer.cancel();
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        btnStart.setText("▶ Resume");
    }

    private void reset() {
        running = false;
        if (timer != null) {
            timer.cancel();
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        remainingMs = currentMinutes() * 60 * 1000L;
        tvMode.setText(focus ? "🎯 Focus time" : "☕ Break time");
        btnSwitch.setText(focus ? "Switch to break" : "Switch to focus");
        btnStart.setText("▶ Start");
        showMinutes();
        showTime();
    }

    private void showTime() {
        long totalSec = (remainingMs + 999) / 1000;
        tvTime.setText(String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60));
    }

    private void onSessionFinished() {
        running = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (focus) {
            sessionsDone++;
            Prefs prefs = new Prefs(getApplicationContext());
            prefs.addXp(FOCUS_XP);
            prefs.markStudiedToday();
            tvDone.setText("✅ Focus sessions today: " + sessionsDone + "   (+" + (sessionsDone * FOCUS_XP) + " XP)");
            new MaterialAlertDialogBuilder(this)
                    .setTitle("🎉 Focus session complete!")
                    .setMessage("You earned +" + FOCUS_XP + " XP. Time for a short break!")
                    .setPositiveButton("Start break", (d, w) -> {
                        focus = false;
                        reset();
                        start();
                    })
                    .setNegativeButton("Not now", (d, w) -> reset())
                    .show();
        } else {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("☕ Break is over")
                    .setMessage("Ready for another focus session?")
                    .setPositiveButton("Focus!", (d, w) -> {
                        focus = true;
                        reset();
                        start();
                    })
                    .setNegativeButton("Later", (d, w) -> {
                        focus = true;
                        reset();
                    })
                    .show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
