package com.studybuddy.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.studybuddy.app.MainActivity;
import com.studybuddy.app.R;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Auth;

/** Create a new StudyBuddy account. */
public class SignUpActivity extends AppCompatActivity {

    private TextInputEditText etName;
    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private TextInputEditText etConfirm;
    private TextView tvError;
    private MaterialButton btnCreate;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        etName = findViewById(R.id.et_name);
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm);
        tvError = findViewById(R.id.tv_error);
        btnCreate = findViewById(R.id.btn_create);
        progress = findViewById(R.id.progress);

        btnCreate.setOnClickListener(v -> attemptSignUp());
        etConfirm.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptSignUp();
                return true;
            }
            return false;
        });
        findViewById(R.id.tv_to_login).setOnClickListener(v -> finish());
    }

    private static String value(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString();
    }

    private void attemptSignUp() {
        final String name = value(etName);
        final String username = value(etUsername);
        final String password = value(etPassword);
        final String confirm = value(etConfirm);
        tvError.setVisibility(View.GONE);
        setBusy(true);
        Async.<Auth.Result>load(
                () -> Auth.register(getApplicationContext(), name, username, password, confirm), res -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            setBusy(false);
            if (res == null) {
                showError("Something went wrong. Please try again.");
            } else if (!res.ok()) {
                showError(res.error);
            } else {
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }
        });
    }

    private void showError(String message) {
        tvError.setText(message);
        tvError.setVisibility(View.VISIBLE);
    }

    private void setBusy(boolean busy) {
        btnCreate.setEnabled(!busy);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }
}
