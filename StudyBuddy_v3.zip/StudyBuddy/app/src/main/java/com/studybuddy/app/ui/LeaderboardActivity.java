package com.studybuddy.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.studybuddy.app.R;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.User;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Session;

import java.util.ArrayList;
import java.util.List;

/** Ranks every account on this device by XP. */
public class LeaderboardActivity extends AppCompatActivity {

    private final List<User> users = new ArrayList<>();
    private RankAdapter adapter;
    private TextView tvEmpty;
    private long myId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        setTitle("🏆 Leaderboard");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        myId = Session.userId(this);
        tvEmpty = findViewById(R.id.tv_empty);
        RecyclerView rv = findViewById(R.id.rv_rank);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RankAdapter();
        rv.setAdapter(adapter);

        Async.<List<User>>load(() -> AppDatabase.get(getApplicationContext()).dao().topUsers(50), list -> {
            if (isFinishing() || isDestroyed() || list == null) {
                return;
            }
            users.clear();
            users.addAll(list);
            adapter.notifyDataSetChanged();
            tvEmpty.setVisibility(users.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    private final class RankAdapter extends RecyclerView.Adapter<RankAdapter.Holder> {

        final class Holder extends RecyclerView.ViewHolder {
            final View root;
            final TextView tvRank;
            final TextView tvName;
            final TextView tvXp;

            Holder(@NonNull View v) {
                super(v);
                root = v;
                tvRank = v.findViewById(R.id.tv_rank);
                tvName = v.findViewById(R.id.tv_name);
                tvXp = v.findViewById(R.id.tv_xp);
            }
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rank, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            User u = users.get(position);
            String[] medals = {"🥇", "🥈", "🥉"};
            h.tvRank.setText(position < 3 ? medals[position] : String.valueOf(position + 1));
            boolean me = u.id == myId;
            h.tvName.setText(u.displayName + (me ? "  (you)" : "") + "\n@" + u.username);
            h.tvXp.setText("Lv " + (u.xp / 100 + 1) + "\n" + u.xp + " XP");
            h.root.setAlpha(1f);
            h.root.setBackgroundResource(me ? R.drawable.rank_me : R.drawable.rank_row);
        }

        @Override
        public int getItemCount() {
            return users.size();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
