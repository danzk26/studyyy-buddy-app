package com.studybuddy.app.ai;

import android.content.Context;

import com.studybuddy.app.util.AppSettings;
import com.studybuddy.app.util.Net;

import java.util.ArrayList;
import java.util.List;

/** Asks the online AI to write study notes (a reviewer) about any topic. */
public final class NotesAI {
    private NotesAI() {
    }

    /** Call from a background thread. */
    public static AiResult<String> write(Context context, String topic, String subjectHint) {
        if (!Net.isOnline(context)) {
            return AiResult.fail("No internet connection. The AI needs to be online.");
        }
        if (!AppSettings.hasApiKey(context)) {
            return AiResult.fail("No API key yet. Add your Gemini key in Me > Settings.");
        }
        String prompt = "Write clear study notes (a reviewer) about: " + topic
                + (subjectHint == null || subjectHint.isEmpty() ? "" : "\nSubject area: " + subjectHint)
                + "\n\nRequirements: 200 to 350 words, accurate facts, plain full sentences "
                + "(one idea per sentence, include definitions, key terms, numbers and dates where relevant), "
                + "no markdown symbols, no title line, no bullet characters.";
        List<GeminiClient.Turn> turns = new ArrayList<>();
        turns.add(new GeminiClient.Turn("user", prompt));
        try {
            GeminiClient.Reply reply = GeminiClient.generate(AppSettings.apiKey(context),
                    AppSettings.model(context),
                    "You are an expert teacher who writes accurate, easy-to-study notes.",
                    turns, null, 0.5, 2048, false);
            return AiResult.ok(reply.text.replace("**", "").replace("#", "").trim());
        } catch (GeminiClient.GeminiException e) {
            return AiResult.fail(e.getMessage());
        }
    }
}
