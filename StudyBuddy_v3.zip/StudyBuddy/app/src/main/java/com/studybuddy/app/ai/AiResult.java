package com.studybuddy.app.ai;

/** Either a value or a friendly error message. Used for every online AI call. */
public final class AiResult<T> {
    public final T value;
    public final String error;

    private AiResult(T value, String error) {
        this.value = value;
        this.error = error;
    }

    public static <T> AiResult<T> ok(T value) {
        return new AiResult<>(value, null);
    }

    public static <T> AiResult<T> fail(String error) {
        return new AiResult<>(null, error);
    }

    public boolean ok() {
        return error == null;
    }
}
