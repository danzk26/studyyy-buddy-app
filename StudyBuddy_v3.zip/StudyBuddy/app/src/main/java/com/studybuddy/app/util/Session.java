package com.studybuddy.app.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.studybuddy.app.data.User;

/** Remembers who is logged in. */
public final class Session {
    private Session() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("session", Context.MODE_PRIVATE);
    }

    public static boolean isLoggedIn(Context c) {
        return userId(c) > 0;
    }

    public static long userId(Context c) {
        return sp(c).getLong("userId", 0);
    }

    public static String username(Context c) {
        return sp(c).getString("username", "");
    }

    public static String displayName(Context c) {
        return sp(c).getString("displayName", "Student");
    }

    public static void login(Context c, User u) {
        sp(c).edit()
                .putLong("userId", u.id)
                .putString("username", u.username)
                .putString("displayName", u.displayName)
                .apply();
    }

    public static void setDisplayName(Context c, String name) {
        sp(c).edit().putString("displayName", name).apply();
    }

    public static void logout(Context c) {
        sp(c).edit().clear().apply();
    }
}
