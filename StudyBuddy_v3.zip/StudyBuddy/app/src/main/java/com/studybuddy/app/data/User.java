package com.studybuddy.app.data;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** A StudyBuddy account. The password itself is never stored, only a salted hash. */
@Entity(indices = {@Index(value = {"username"}, unique = true)})
public class User {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String username;
    public String displayName;
    public String salt;
    public String passwordHash;
    public int xp;
    public long createdAt;

    public User() {
    }

    @Ignore
    public User(String username, String displayName, String salt, String passwordHash) {
        this.username = username;
        this.displayName = displayName;
        this.salt = salt;
        this.passwordHash = passwordHash;
        this.xp = 0;
        this.createdAt = System.currentTimeMillis();
    }
}
