package com.studybuddy.app.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.studybuddy.app.BuildConfig;

/** Device-wide settings: the AI key, the AI model and the teacher's voice. */
public final class AppSettings {
    public static final String DEFAULT_MODEL = "gemini-2.5-flash";

    private AppSettings() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    /** The key typed in Settings wins; otherwise the key from local.properties (BuildConfig). */
    public static String apiKey(Context c) {
        String k = sp(c).getString("apiKey", "");
        if (k == null || k.trim().isEmpty()) {
            k = BuildConfig.GEMINI_API_KEY;
        }
        return k == null ? "" : k.trim();
    }

    public static String savedApiKey(Context c) {
        return sp(c).getString("apiKey", "");
    }

    public static boolean hasApiKey(Context c) {
        return !apiKey(c).isEmpty();
    }

    public static void setApiKey(Context c, String key) {
        sp(c).edit().putString("apiKey", key == null ? "" : key.trim()).apply();
    }

    public static String model(Context c) {
        String m = sp(c).getString("model", DEFAULT_MODEL);
        return (m == null || m.trim().isEmpty()) ? DEFAULT_MODEL : m.trim();
    }

    public static void setModel(Context c, String model) {
        sp(c).edit().putString("model", model == null ? "" : model.trim()).apply();
    }

    public static boolean voiceOn(Context c) {
        return sp(c).getBoolean("voiceOn", true);
    }

    public static void setVoiceOn(Context c, boolean on) {
        sp(c).edit().putBoolean("voiceOn", on).apply();
    }

    public static float speechRate(Context c) {
        return sp(c).getFloat("speechRate", 1.0f);
    }

    public static void setSpeechRate(Context c, float rate) {
        sp(c).edit().putFloat("speechRate", rate).apply();
    }
}
