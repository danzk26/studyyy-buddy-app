package com.studybuddy.app;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Seeder;
import com.studybuddy.app.ui.HomeFragment;
import com.studybuddy.app.ui.LibraryFragment;
import com.studybuddy.app.ui.LoginActivity;
import com.studybuddy.app.ui.PlayFragment;
import com.studybuddy.app.ui.ProfileFragment;
import com.studybuddy.app.ui.TeacherFragment;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Session;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Session.isLoggedIn(this)) {
            goToLogin();
            return;
        }
        setContentView(R.layout.activity_main);
        final boolean fresh = savedInstanceState == null;
        final BottomNavigationView nav = findViewById(R.id.bottom_nav);
        final long uid = Session.userId(this);

        // Create the built-in database content on first launch, and make sure the account still exists.
        Async.<Boolean>load(() -> {
            Seeder.ensureSeeded(getApplicationContext());
            return AppDatabase.get(getApplicationContext()).dao().user(uid) != null;
        }, accountExists -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            if (Boolean.FALSE.equals(accountExists)) {
                Session.logout(this);
                goToLogin();
                return;
            }
            nav.setOnItemSelectedListener(item -> {
                Fragment f;
                int id = item.getItemId();
                if (id == R.id.nav_library) {
                    f = new LibraryFragment();
                } else if (id == R.id.nav_play) {
                    f = new PlayFragment();
                } else if (id == R.id.nav_teacher) {
                    f = new TeacherFragment();
                } else if (id == R.id.nav_me) {
                    f = new ProfileFragment();
                } else {
                    f = new HomeFragment();
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.container, f).commit();
                return true;
            });
            if (fresh) {
                nav.setSelectedItemId(R.id.nav_home);
            }
        });
    }

    private void goToLogin() {
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
