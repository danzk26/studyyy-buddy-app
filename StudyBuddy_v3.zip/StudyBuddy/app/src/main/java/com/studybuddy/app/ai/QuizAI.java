package com.studybuddy.app.ai;

import android.content.Context;

import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Question;
import com.studybuddy.app.data.Reviewer;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.util.AppSettings;
import com.studybuddy.app.util.Net;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Makes quiz questions from a reviewer: with the online AI when possible, otherwise on-device. */
public final class QuizAI {
    private QuizAI() {
    }

    public static final class Generated {
        public final List<Question> questions;
        public final boolean usedOnlineAi;

        Generated(List<Question> questions, boolean usedOnlineAi) {
            this.questions = questions;
            this.usedOnlineAi = usedOnlineAi;
        }
    }

    /** Call from a background thread. Never throws: falls back to the offline generator. */
    public static Generated generate(Context context, Reviewer r, int count, long uid) {
        List<Question> list = null;
        boolean online = false;
        if (Net.isOnline(context) && AppSettings.hasApiKey(context)) {
            try {
                list = askOnlineAi(context, r, count);
                online = list != null && !list.isEmpty();
            } catch (Exception e) {
                list = null;
            }
        }
        if (list == null || list.isEmpty()) {
            StudyDao dao = AppDatabase.get(context).dao();
            list = LocalAI.generateQuestions(r, count, LocalAI.termPool(dao.reviewers(uid)));
            online = false;
        }
        for (Question q : list) {
            q.userId = uid;
            q.subjectId = r.subjectId;
            q.reviewerId = r.id;
        }
        return new Generated(list, online);
    }

    private static List<Question> askOnlineAi(Context context, Reviewer r, int count) throws Exception {
        String notes = r.content == null ? "" : r.content;
        if (notes.length() > 9000) {
            notes = notes.substring(0, 9000);
        }
        String prompt = "Create " + count + " multiple-choice questions that test a student on the study notes below.\n"
                + "Return ONLY a JSON array. Each item must be: "
                + "{\"question\": string, \"options\": [exactly 4 strings], \"correctIndex\": 0-3, \"explanation\": string}.\n"
                + "Rules: wrong options must be plausible, put the correct answer in different positions, "
                + "mix easy and harder questions, keep each question under 200 characters, "
                + "do not number the options.\n\n"
                + "Notes title: " + r.title + "\n\nNotes:\n" + notes;
        List<GeminiClient.Turn> turns = new ArrayList<>();
        turns.add(new GeminiClient.Turn("user", prompt));
        GeminiClient.Reply reply = GeminiClient.generate(AppSettings.apiKey(context),
                AppSettings.model(context), "You write accurate, fair quiz questions for students.",
                turns, null, 0.6, 4096, true);
        return parseQuestions(reply.text);
    }

    static List<Question> parseQuestions(String raw) throws Exception {
        String s = raw.trim();
        if (s.startsWith("```")) {
            s = s.replaceFirst("^```[a-zA-Z]*\\s*", "").replaceFirst("\\s*```$", "").trim();
        }
        int start = s.indexOf('[');
        int end = s.lastIndexOf(']');
        if (start < 0 || end <= start) {
            throw new Exception("No question list in the answer");
        }
        JSONArray arr = new JSONArray(s.substring(start, end + 1));
        List<Question> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) {
                continue;
            }
            String text = o.optString("question", "").trim();
            JSONArray opts = o.optJSONArray("options");
            int correct = o.optInt("correctIndex", -1);
            if (text.isEmpty() || opts == null || opts.length() != 4 || correct < 0 || correct > 3) {
                continue;
            }
            String[] options = new String[4];
            boolean valid = true;
            for (int k = 0; k < 4; k++) {
                options[k] = opts.optString(k, "").trim();
                if (options[k].isEmpty()) {
                    valid = false;
                }
            }
            if (!valid) {
                continue;
            }
            Question q = new Question();
            q.question = text;
            q.a = options[0];
            q.b = options[1];
            q.c = options[2];
            q.d = options[3];
            q.correct = correct;
            String exp = o.optString("explanation", "").trim();
            q.explanation = exp.isEmpty() ? "The correct answer is: " + options[correct] : exp;
            q.source = 2;
            out.add(q);
        }
        Collections.shuffle(out);
        return out;
    }
}
