package com.studybuddy.app.ai;

import android.content.Context;

import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.ChatMessage;
import com.studybuddy.app.data.QuizResult;
import com.studybuddy.app.data.Reviewer;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.data.Subject;
import com.studybuddy.app.util.AppSettings;
import com.studybuddy.app.util.Net;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The online AI Teacher (Google Gemini). It remembers the conversation, knows the student's
 * reviewers and quiz results, can teach any topic, and can use two tools:
 *  - create_reviewer : write a new reviewer (notes) on any topic and save it to the library
 *  - start_quiz      : open a quiz
 */
public final class TeacherAI {
    /** Special error text meaning "the student has not entered an API key yet". */
    public static final String NO_KEY = "NO_KEY";

    private TeacherAI() {
    }

    public static final class Result {
        public String text = "";
        /** "create_reviewer", "start_quiz" or null. */
        public String action;
        public JSONObject args;
    }

    /** Call from a background thread. history = messages BEFORE the new one. */
    public static AiResult<Result> chat(Context context, String userName, long uid,
                                        List<ChatMessage> history, String userText) {
        if (!Net.isOnline(context)) {
            return AiResult.fail("No internet connection. The AI Teacher needs to be online.");
        }
        if (!AppSettings.hasApiKey(context)) {
            return AiResult.fail(NO_KEY);
        }
        try {
            StudyDao dao = AppDatabase.get(context).dao();
            List<Reviewer> revs = dao.reviewers(uid);
            List<QuizResult> results = dao.recentResults(uid, 30);
            Map<Long, String> names = new HashMap<>();
            for (Subject s : dao.subjects(uid)) {
                names.put(s.id, s.name);
            }
            String system = buildSystem(userName, revs, results, names);

            List<GeminiClient.Turn> turns = new ArrayList<>();
            int from = Math.max(0, history.size() - 14);
            for (int i = from; i < history.size(); i++) {
                ChatMessage m = history.get(i);
                if (m.text == null || m.text.trim().isEmpty()) {
                    continue;
                }
                String role = m.fromUser ? "user" : "model";
                if (turns.isEmpty() && !m.fromUser) {
                    continue; // a conversation must start with the student
                }
                turns.add(new GeminiClient.Turn(role, m.text));
            }
            turns.add(new GeminiClient.Turn("user", userText));

            GeminiClient.Reply reply = GeminiClient.generate(AppSettings.apiKey(context),
                    AppSettings.model(context), system, turns, tools(), 0.7, 2048, false);
            Result r = new Result();
            r.text = reply.text;
            r.action = reply.functionName;
            r.args = reply.functionArgs;
            return AiResult.ok(r);
        } catch (GeminiClient.GeminiException e) {
            return AiResult.fail(e.getMessage());
        } catch (Exception e) {
            return AiResult.fail("Something went wrong: " + e.getMessage());
        }
    }

    private static String buildSystem(String userName, List<Reviewer> revs, List<QuizResult> results,
                                      Map<Long, String> names) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are StudyBuddy's AI Teacher: a warm, patient, brilliant tutor talking with ")
                .append(userName).append(".\n");
        sb.append("How to teach: explain step by step in simple words, give one short example, and when you ")
                .append("teach something end with ONE quick question to check understanding. Adapt to the ")
                .append("student's level and encourage them.\n");
        sb.append("Style: your replies are read aloud, so keep them concise (usually under 150 words), ")
                .append("use short paragraphs, light markdown only (**bold**, '- ' bullets), no tables, no long code.\n");
        sb.append("You can teach ANY topic, not only the student's notes. When the student's notes are ")
                .append("relevant, use them and mention which reviewer you used.\n");
        sb.append("Tools: call create_reviewer when the student asks you to create/make/write/generate a ")
                .append("reviewer, notes, lesson, study guide or topic (put complete, accurate notes of 150-350 words ")
                .append("as plain full sentences in 'content'). Call start_quiz when the student asks to be quizzed ")
                .append("or tested. After a tool call, also write one friendly sentence.\n");

        sb.append("\nStudent's reviewers (titles and excerpts):\n");
        int budget = 6000;
        int shown = 0;
        for (Reviewer r : revs) {
            if (shown >= 12 || budget <= 0) {
                break;
            }
            String content = r.content == null ? "" : r.content.replace("\n", " ");
            String excerpt = content.length() > 450 ? content.substring(0, 450) + "..." : content;
            String line = "- " + r.title + " (" + names.get(r.subjectId) + "): " + excerpt + "\n";
            sb.append(line);
            budget -= line.length();
            shown++;
        }
        if (shown == 0) {
            sb.append("(none yet)\n");
        }

        Map<Long, int[]> per = new HashMap<>();
        for (QuizResult q : results) {
            int[] a = per.get(q.subjectId);
            if (a == null) {
                a = new int[2];
                per.put(q.subjectId, a);
            }
            a[0] += q.score;
            a[1] += q.total;
        }
        if (!per.isEmpty()) {
            sb.append("\nStudent's recent quiz accuracy by subject:\n");
            for (Map.Entry<Long, int[]> e : per.entrySet()) {
                int[] a = e.getValue();
                String n = e.getKey() == 0 ? "Mixed" : names.get(e.getKey());
                if (a[1] > 0) {
                    sb.append("- ").append(n).append(": ")
                            .append(String.format(Locale.US, "%d%%", Math.round(100f * a[0] / a[1]))).append("\n");
                }
            }
        }
        return sb.toString();
    }

    private static JSONArray tools() throws Exception {
        JSONObject createProps = new JSONObject()
                .put("title", new JSONObject().put("type", "STRING").put("description", "Short title of the reviewer"))
                .put("subject", new JSONObject().put("type", "STRING").put("description", "Subject name, e.g. Science, Math, History"))
                .put("content", new JSONObject().put("type", "STRING")
                        .put("description", "The full study notes: 150-350 words, plain full sentences"));
        JSONObject create = new JSONObject()
                .put("name", "create_reviewer")
                .put("description", "Create a new reviewer (study notes) and save it to the student's library with quiz questions.")
                .put("parameters", new JSONObject()
                        .put("type", "OBJECT")
                        .put("properties", createProps)
                        .put("required", new JSONArray().put("title").put("subject").put("content")));

        JSONObject quizProps = new JSONObject()
                .put("subject", new JSONObject().put("type", "STRING")
                        .put("description", "Subject name to quiz on, or empty for all subjects"))
                .put("count", new JSONObject().put("type", "INTEGER").put("description", "Number of questions, 3 to 15"));
        JSONObject quiz = new JSONObject()
                .put("name", "start_quiz")
                .put("description", "Open a multiple-choice quiz for the student.")
                .put("parameters", new JSONObject().put("type", "OBJECT").put("properties", quizProps));

        return new JSONArray().put(new JSONObject()
                .put("functionDeclarations", new JSONArray().put(create).put(quiz)));
    }
}
