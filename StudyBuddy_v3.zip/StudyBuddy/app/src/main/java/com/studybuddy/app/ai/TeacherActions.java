package com.studybuddy.app.ai;

import android.content.Context;

import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Question;
import com.studybuddy.app.data.Reviewer;
import com.studybuddy.app.data.StudyDao;
import com.studybuddy.app.data.Subject;

import java.util.List;
import java.util.Locale;

/** Things the AI Teacher can do for the student. Call from a background thread. */
public final class TeacherActions {
    private TeacherActions() {
    }

    public static final class Created {
        public long reviewerId;
        public String title;
        public String subject;
        public int questions;
        public boolean onlineQuestions;
    }

    public static Created createReviewer(Context context, long uid, String subjectName,
                                         String title, String content) {
        StudyDao dao = AppDatabase.get(context).dao();
        String subj = subjectName == null ? "" : subjectName.trim();
        if (subj.isEmpty()) {
            subj = "General";
        }
        if (subj.length() > 30) {
            subj = subj.substring(0, 30);
        }
        String ttl = title == null || title.trim().isEmpty() ? "AI Topic" : title.trim();

        Subject s = dao.subjectByName(subj, uid);
        if (s == null) {
            s = new Subject(subj, emojiFor(subj + " " + ttl));
            s.userId = uid;
            s.id = dao.insertSubject(s);
        }
        Reviewer r = new Reviewer(s.id, ttl, content == null ? "" : content.trim());
        r.userId = uid;
        r.summary = LocalAI.summarize(r.content, 3);
        r.id = dao.insertReviewer(r);

        QuizAI.Generated g = QuizAI.generate(context, r, 10, uid);
        List<Question> qs = g.questions;
        dao.insertQuestions(qs);

        Created c = new Created();
        c.reviewerId = r.id;
        c.title = ttl;
        c.subject = s.name;
        c.questions = qs.size();
        c.onlineQuestions = g.usedOnlineAi;
        return c;
    }

    /** Returns the subject id for a name the AI gave, or 0 (all subjects). */
    public static long findSubjectId(Context context, long uid, String name) {
        if (name == null || name.trim().isEmpty()) {
            return 0;
        }
        Subject s = AppDatabase.get(context).dao().subjectByName(name.trim(), uid);
        return s == null ? 0 : s.id;
    }

    public static String emojiFor(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        if (t.matches(".*(science|biolog|chem|physic|astronom|cell).*")) return "🔬";
        if (t.matches(".*(math|algebra|geometry|calculus|statistic).*")) return "📐";
        if (t.matches(".*(histor|civics|politic|government).*")) return "🏛️";
        if (t.matches(".*(english|literature|grammar|language|writing).*")) return "📚";
        if (t.matches(".*(computer|program|coding|software|java|python|network).*")) return "💻";
        if (t.matches(".*(geograph|earth|environment|climate).*")) return "🌍";
        if (t.matches(".*(art|design|paint).*")) return "🎨";
        if (t.matches(".*(music|song|instrument).*")) return "🎵";
        if (t.matches(".*(econom|business|finance|account).*")) return "💰";
        if (t.matches(".*(health|medic|nurs|anatomy).*")) return "🩺";
        return "💡";
    }
}
