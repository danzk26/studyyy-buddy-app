package com.studybuddy.app.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Reads a file chosen by the user (any Uri) and returns CLEAN readable text.
 * Supports PDF, Word (.docx), PowerPoint (.pptx) and plain text files (.txt, .md, .csv ...).
 * Call it from a background thread (PDF reading can take a moment).
 */
public final class DocumentTextExtractor {

    private static final int MAX_BYTES = 25 * 1024 * 1024; // 25 MB
    private static final int MAX_PDF_PAGES = 80;

    private DocumentTextExtractor() {}

    /** The real file name (for example "Cell Biology.pdf"). */
    public static String getDisplayName(Context context, Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor c = context.getContentResolver()
                    .query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) name = c.getString(idx);
                }
            } catch (Exception ignored) {
                // fall back to the path below
            }
        }
        if (name == null || name.isEmpty()) {
            name = uri.getLastPathSegment();
            if (name != null && name.contains("/")) {
                name = name.substring(name.lastIndexOf('/') + 1);
            }
        }
        return (name == null || name.isEmpty()) ? "Uploaded file" : name;
    }

    public static String extract(Context context, Uri uri) throws IOException {
        byte[] data;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Cannot open the selected file.");
            data = readAll(in);
        }

        String text;
        if (DocumentParsers.detect(data) == DocumentParsers.Type.PDF) {
            text = DocumentParsers.cleanText(extractPdf(context, data));
        } else {
            text = DocumentParsers.extractText(data); // already cleaned
        }

        if (text.isEmpty()) {
            throw new DocumentParsers.UnsupportedDocumentException(
                    "No readable text was found. If this is a scanned PDF or a picture, "
                            + "it needs OCR, which is not supported yet.");
        }
        if (DocumentParsers.looksBinary(text)) {
            throw new DocumentParsers.UnsupportedDocumentException(
                    "The text in this file could not be decoded correctly.");
        }
        return text;
    }

    private static String extractPdf(Context context, byte[] data) throws IOException {
        PDFBoxResourceLoader.init(context.getApplicationContext());
        PDDocument document = null;
        try {
            document = PDDocument.load(new ByteArrayInputStream(data));
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setStartPage(1);
            stripper.setEndPage(Math.max(1, Math.min(document.getNumberOfPages(), MAX_PDF_PAGES)));
            return stripper.getText(document);
        } catch (OutOfMemoryError oom) {
            throw new DocumentParsers.UnsupportedDocumentException(
                    "This PDF is too large to read on this device.");
        } catch (IOException e) {
            throw new DocumentParsers.UnsupportedDocumentException(
                    "Could not read this PDF. It may be password-protected or damaged.");
        } finally {
            if (document != null) {
                try {
                    document.close();
                } catch (IOException ignored) {
                    // nothing to do
                }
            }
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        long total = 0;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > MAX_BYTES) {
                throw new DocumentParsers.UnsupportedDocumentException("The file is too large (max 25 MB).");
            }
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }
}
