package com.studybuddy.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.studybuddy.app.R;
import com.studybuddy.app.data.AppDatabase;
import com.studybuddy.app.data.Question;
import com.studybuddy.app.data.QuizResult;
import com.studybuddy.app.util.Async;
import com.studybuddy.app.util.Prefs;
import com.studybuddy.app.util.Session;

import java.util.List;

/** 2D arcade game: catch the correct answer as it falls. */
public class CatchGameActivity extends AppCompatActivity implements CatchGameView.Listener {

    public static final String EXTRA_SUBJECT = "subject";
    private static final int ROUNDS = 10;

    private CatchGameView game;
    private TextView tvScore;
    private TextView tvLives;
    private TextView tvRound;
    private TextView tvQuestion;
    private TextView tvFeedback;
    private long subjectId;
    private boolean started = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catch_game);
        setTitle("🦊 Answer Catcher");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        subjectId = getIntent().getLongExtra(EXTRA_SUBJECT, 0);
        game = findViewById(R.id.game_view);
        tvScore = findViewById(R.id.tv_score);
        tvLives = findViewById(R.id.tv_lives);
        tvRound = findViewById(R.id.tv_round);
        tvQuestion = findViewById(R.id.tv_question);
        tvFeedback = findViewById(R.id.tv_feedback);
        game.setListener(this);

        final Context appContext = getApplicationContext();
        final long uid = Session.userId(appContext);
        Async.<List<Question>>load(() -> AppDatabase.get(appContext).dao().randomQuestions(subjectId, uid, ROUNDS), list -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            if (list == null || list.isEmpty()) {
                Toast.makeText(this, "No questions yet — add notes in the Library first!", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            game.setQuestions(list);
            started = true;
            game.start();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        game.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (started) {
            game.resume();
        }
    }

    // ---- game callbacks (always on the main thread) ----
    @Override
    public void onQuestion(Question q, int number, int total) {
        tvQuestion.setText(q.question);
        tvRound.setText("Round " + number + " / " + total);
        tvFeedback.setText("Drag to move the fox 🦊");
    }

    @Override
    public void onStats(int score, int lives, int combo) {
        tvScore.setText("⭐ " + score + (combo >= 2 ? "  🔥x" + combo : ""));
        StringBuilder hearts = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            hearts.append(i < lives ? "❤️" : "🖤");
        }
        tvLives.setText(hearts.toString());
    }

    @Override
    public void onFeedback(String message, boolean good) {
        tvFeedback.setText(message);
    }

    @Override
    public void onGameOver(int correct, int played, int xp, boolean finishedAll) {
        final int total = Math.max(1, played);
        final Context appContext = getApplicationContext();
        final QuizResult result = new QuizResult(subjectId, "catch", correct, total, xp);
        result.userId = Session.userId(appContext);
        Prefs prefs = new Prefs(appContext);
        int levelBefore = prefs.level();
        prefs.addXp(xp);
        prefs.markStudiedToday();
        boolean levelUp = prefs.level() > levelBefore;
        Async.io(() -> AppDatabase.get(appContext).dao().insertResult(result));

        String verdict = finishedAll ? "🏆 You caught them all!" : "💔 Out of hearts!";
        String message = "You caught " + correct + " correct answers out of " + total + " rounds\n\n"
                + "⭐ +" + xp + " XP\n🔥 Best combo: x" + game.getBestCombo()
                + (levelUp ? "\n\n🆙 LEVEL UP! You're now level " + prefs.level() + "!" : "");
        new MaterialAlertDialogBuilder(this)
                .setTitle(verdict)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Done", (d, w) -> finish())
                .setNegativeButton("Play again", (d, w) -> {
                    startActivity(getIntent());
                    finish();
                })
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
